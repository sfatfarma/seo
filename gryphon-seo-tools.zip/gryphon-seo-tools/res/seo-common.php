<?php
function fwd_seo_common_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group6');
    do_settings_sections('seo_option_group6');
    $seo_Common_Settings = get_option('seo_Common_Settings', false);
    $seo_common = $seo_Common_Settings['seo_common'];
    $seo_dublin = $seo_Common_Settings['seo_dublin'];
    $seo_canonical = $seo_Common_Settings['seo_canonical'];
    if (isset($seo_Common_Settings['seo_copyright'])) {
        $seo_copyright = esc_html(sanitize_text_field($seo_Common_Settings['seo_copyright']));
    } else {
        $seo_copyright = '';
    }
    if (isset($seo_Common_Settings['seo_language'])) {
        $seo_language = esc_html(sanitize_text_field($seo_Common_Settings['seo_language']));
    } else {
        $seo_language = '';
    }
    if (isset($seo_Common_Settings['seo_author'])) {
        $seo_author = esc_html(sanitize_text_field($seo_Common_Settings['seo_author']));
    } else {
        $seo_author = '';
    }
    if (isset($seo_Common_Settings['seo_abstract'])) {
        $seo_abstract = esc_html(sanitize_text_field($seo_Common_Settings['seo_abstract']));
    } else {
        $seo_abstract = '';
    }
?><script>
                var seo_admin_json = {
                    copyright: '<?php
    echo $seo_copyright;
?>',
                    language: '<?php
    echo $seo_language;
?>',
                    author: '<?php
    echo $seo_author;
?>',
                    abstract: '<?php
    echo $seo_abstract;
?>'
                    }
            </script>
            <script type="text/javascript">
    window.onload = cChanged;
    function cChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".cHide").show();
        else
            jQuery(".cHide").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table><tr><td>
    <span class="gs-sub-heading"><b>Common Meta Tags:</b></span>
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "These meta tags have lower SEO value, but still may represent the leading inch in front of your competition.";
?>
                        </div>
                    </div>
    </td>
    <td>
    <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_common" name="seo_Common_Settings[seo_common]" onchange="cChanged()"<?php
    if ($seo_common == 'on')
        echo ' checked ';
?>>
                            <label for="seo_common"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <div class="cHide">
                    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Copyright:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "How do you explain that the photos and the text on your website are protected? You use the so called COPYRIGHT meta tag. Add your or your company's name.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Common_Settings[seo_copyright]" ng-model="settings.copyright" size="68" placeholder="copyright_owner">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Language:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "How do you explain in which language your website is in? You use the so called LANGUAGE tag. Exemple: english, spanish, romanian.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Common_Settings[seo_language]" ng-model="settings.language" size="68" placeholder="language_of_the_page">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Author:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "How to give credit to the person of company that made your website? You use the so called AUTHOR tag. There are also Content Management Systems (CMS) who will put the name of the actual person editing the page. If used like this, it is easy to find the right person who is responsible for a webpage.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Common_Settings[seo_author]" ng-model="settings.author" size="68" placeholder="author_name">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Abstract:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The meta tag abstract can be used to indicate in just a very short sentence what the webpage is about. So every webpage of your website gets it's own abstract-tag. Useful for SEO in some rare cases.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Common_Settings[seo_abstract]" ng-model="settings.abstract" size="68" placeholder="a_short_description">
            </div>
        </div>
        <input type="checkbox" id="seo_dublin" name="seo_Common_Settings[seo_dublin]"<?php
    if ($seo_dublin == 'on')
        echo ' checked ';
?>>
        Dublin Core meta tags
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
            <div class="bws_hidden_help_text" style="min-width: 260px;">
                <?php
    echo "The Dublin Core Metadata Initiative is an open organization engaged in the development of interoperable online metadata standards that support a broad range of purposes and business models.This metadata has hardly any influence on the ranking of your site with the search engines. It has to be said that if your pages can be archived better, they will be found more easily.";
?>
            </div>
        </div>
        <br/>
        <input type="checkbox" id="seo_canonical" name="seo_Common_Settings[seo_canonical]"<?php
    if ($seo_canonical == 'on')
        echo ' checked ';
?>>
        Show Canonical meta tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
            <div class="bws_hidden_help_text" style="min-width: 260px;">
                <?php
    echo "Adding 'canonical' meta tag in your source makes search engines understand what the main page if you have double content.  By guiding the search engine to the most important page your pagerank will be set on the right page. This is better for your ranking and results.";
?>
            </div>
        </div>
        </div>
</div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
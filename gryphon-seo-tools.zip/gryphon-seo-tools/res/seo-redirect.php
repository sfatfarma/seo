<?php
if (isset($_POST['gryphon_301_redirects'])) {
	add_action('admin_init', 'gryphon_save_redirects');
}
function gryphon_save_redirects($data) 
{
            check_admin_referer( 'gryphon_save_redirects', '_gryphonr_nonce' );
			$data = $_POST['gryphon_301_redirects'];

			$redirects = array();
			
			for($i = 0; $i < sizeof($data['request']); ++$i) {
                $bundle = array();
				$request = trim( sanitize_text_field( $data['request'][$i] ) );
				$bundle[] = trim( sanitize_text_field( $data['destination'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['device'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['active'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['wildcard'][$i] ) );
				if ($request == '') { continue; }
				else { $redirects[$request] = $bundle; }
			}
			
			update_option('gryphon_301_redirects', $redirects);
}
function fwd_seo_redir_settings()
{
?><div class="wrap seo_pops">
    <div>
    <script>
				jQuery(document).ready(function(){
					jQuery('span.wpgryphon-delete').html('X').css({'color':'red','cursor':'pointer'}).click(function(){
						var confirm_delete = confirm('Delete This Redirect?');
						if (confirm_delete) {
							jQuery(this).parent().parent().remove();
							jQuery('#myForm').submit();						
						}
					});
				});
	</script>
    <script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('#redirect_404_enable').is(":checked"))
        {            
            jQuery(".hide404").show();
        }
        else
        {
            jQuery(".hide404").hide();
        }
    }
    window.onload = mainChanged;
    </script>
        <form id="myForm" method="post" action="options.php"><?php
    wp_nonce_field( 'gryphon_save_redirects', '_gryphonr_nonce' );
    settings_fields('seo_option_group13');
    do_settings_sections('seo_option_group13');
    $seo_Redirect_Settings = get_option('seo_Redirect_Settings', false);
    if (isset($seo_Redirect_Settings['redirect_enable'])) {
        $redirect_enable = $seo_Redirect_Settings['redirect_enable'];
    } else {
        $redirect_enable = '';
    }
    if (isset($seo_Redirect_Settings['redirect_404_enable'])) {
        $redirect_404_enable = $seo_Redirect_Settings['redirect_404_enable'];
    } else {
        $redirect_404_enable = '';
    }
    if (isset($seo_Redirect_Settings['redirect_404_link'])) {
        $redirect_404_link = $seo_Redirect_Settings['redirect_404_link'];
    } else {
        $redirect_404_link = '';
    }
    if (isset($seo_Redirect_Settings['redirect_http'])) {
        $redirect_http = $seo_Redirect_Settings['redirect_http'];
    } else {
        $redirect_http = 'No';
    }
    if (isset($seo_Redirect_Settings['redirect_www'])) {
        $redirect_www = $seo_Redirect_Settings['redirect_www'];
    } else {
        $redirect_www = 'No';
    }
    if (isset($seo_Redirect_Settings['redirect_attachment'])) {
        $redirect_attachment = $seo_Redirect_Settings['redirect_attachment'];
    } else {
        $redirect_attachment = '';
    }
    if (isset($seo_Redirect_Settings['redirect_badbot'])) {
        $redirect_badbot = $seo_Redirect_Settings['redirect_badbot'];
    } else {
        $redirect_badbot = '';
    }
?><script>
                var seo_admin_json = {    
                    redirect_enable: '<?php
    echo $redirect_enable;
?>',
                    redirect_404_enable: '<?php
    echo $redirect_404_enable;
?>',
                    redirect_404_link: '<?php
    echo $redirect_404_link;
?>',
                    redirect_http: '<?php
    echo $redirect_http;
?>',
                    redirect_www: '<?php
    echo $redirect_www;
?>',
                    redirect_attachment: '<?php
    echo $redirect_attachment;
?>',
                    redirect_badbot: '<?php
    echo $redirect_badbot;
?>'
                    }
            </script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <span class="gs-sub-heading"><b>SEO Page Redirect Settings:</b></span><br/>
                    <hr/>
                    <table><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Extended 404 Nearest Match Redirect' feature? This will enable and extend WordPress's build in 'Nearest Match Redirect' feature, making it search, beside posts, also in categories, tags and pages.";
?>
                        </div>
                    </div>
                    <b>Enable 'Extended 404 Nearest Match Redirect':&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_enable" name="seo_Redirect_Settings[redirect_enable]" <?php
    if ($redirect_enable == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable '404 Page' redirect feature? This will disable the build-in 404 error page feature and will redirect all users who entered an invalid link, to a predefined URL.";
?>
                        </div>
                    </div>
                    <b>Enable '404 Page Not Found' Redirect:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_404_enable" name="seo_Redirect_Settings[redirect_404_enable]" onclick="mainChanged()" <?php
    if ($redirect_404_enable == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hide404">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where 404 not found page errors will be redirected. Here you can set a custom 'Page Not Found' page or simply just your home page.";
?>
                        </div>
                    </div>
                    <b>'404 Page Not Found' Redirect Link:</b>
                    
                    </td><td>
                    <div class="hide404">
                    <input type="url" class="textIn" validator="url" name="seo_Redirect_Settings[redirect_404_link]" ng-model="settings.redirect_404_link" >
                    </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This will redirect all HTTP traffic to HTTPS, or vice versa. Warning! Enable this only if you have HTTPS protocol enabled on your site, otherwise this feature will break your site functionality!";
?>
                        </div>
                    </div>
                    <b>'HTTP/HTTPS' Redirect:</b>
                    
                    </td><td>
                    <select name="seo_Redirect_Settings[redirect_http]" ng-model="settings.redirect_http" style="width:160px;max-width:200px;">
                          <option value="No" selected>No Redirect</option>
                          <option value="Https">Force HTTPS</option>
                          <option value="Http">Force HTTP</option>
                    </select>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This will redirect all WWW traffic to non-www, or vice versa. Warning! Enable this only if you know that the version you select is functional, otherwise this feature will break your site functionality!";
?>
                        </div>
                    </div>
                    <b>'www/non-www' Redirect:</b>
                    
                    </td><td>
                    <select name="seo_Redirect_Settings[redirect_www]" ng-model="settings.redirect_www" style="width:160px;max-width:200px;">
                          <option value="No" selected>No Redirect</option>
                          <option value="www">Force www</option>
                          <option value="no-www">Force non-www</option>
                    </select>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature makes attachment pages redirects (301 permanent redirect) to post parent if any. If not, redirects (302 temporal redirect) to home page. Note that this feature is not affected by the timing options set bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Attachment Page Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_attachment" name="seo_Redirect_Settings[redirect_attachment]"<?php
    if ($redirect_attachment == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature blocks all crawling bots except the major ones that will benefit your website (Google, Bing, Yahoo, etc.). For a full list of blocked and allowed bots and spiders, please consult the plugin documentation. This feature can imporove your website's performance.";
?>
                        </div>
                    </div>
                    <b>'Bad Bot' Blocker:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_badbot" name="seo_Redirect_Settings[redirect_badbot]"<?php
    if ($redirect_badbot == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr></table>
        <br/><br/>
        <b>Redirection Rules Manager:</b>
        <hr/>
        <div class="table-responsive">
                    <table class="responsive table" style="overflow-x:auto;">
				<thead>
					<tr>
						<th>URL<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The source URL from where you want to redirect your users. Note that this is the most important field in this table! Note that this field must contain only internal links (stating with /)!";
?>
                        </div>
                    </div></th>
                        <th style="max-width:20px;">*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable usage of wildcards in this rule? You can lear about wildcards and their usage <a href='http://ryanstutorials.net/linuxtutorial/wildcards.php'>here</a>.";
?>
                        </div>
                    </div></th>
						<th>Redirect<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Where do you want to redirect your users? You can also leave this field blank, for 404 like status codes.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:20px;">Delete<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to delete this rule?";
?>
                        </div>
                    </div></th>
                        <th>Crawler selection<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select if the rule affects all visitors, only bots or only bots not.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:32px;" >Active<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable this<br/> plugin? You can deactivate<br/> any rule (you don't have<br/> to delete them to deactivate<br/> them).";
?>
                        </div>
                    </div></th>
					</tr>
				</thead>
				<tbody>
					<?php echo gryphon_expand_redirects(); ?>
					<tr>
						<td style="min-width:100px;width:15%;text-align:center;vertical-align: middle;"><input type="text" pattern="[/][^/].*" placeholder="/yourlink.html" name="gryphon_301_redirects[request][]" value="" style="width:99%;" /></td>
						<td style="max-width:20px;text-align:center;vertical-align: middle;"><input type="checkbox" name="gryphon_301_redirects[wildcard][]" value="1" /></td>
                        <td style="min-width:100px;width:15%;text-align:center;vertical-align: middle;"><input type="url" validator="url" placeholder="http://www.yourRedirect.com" name="gryphon_301_redirects[destination][]" value="" style="width:99%;"/></td>
						<td style="max-width:20px;text-align: center;" ><span style="max-width:20px;" class="wpgryphon-delete"></span></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:180px;" name="gryphon_301_redirects[device][]">
                          <option value="All" selected>All</option>
                          <option value="Bot">Only Crawlers</option>
                          <option value="No-Bot">Excluding Crawlers</option>
                          <option value="Good-Bot">Good Crawlers Only</option>
                          <option value="Bad-Bot">Bad Crawlers Only</option>
                        </select></td>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;"><input type="checkbox" name="gryphon_301_redirects[active][]" value="1" checked /></td>
					</tr>
				</tbody>
			</table>
            <div><input type="button" onclick="saveRedirects()" value="Backup Rules To File" /></div>
            </div>
</div>
</div>
</div>
    </div>
    <script>
                jQuery("form").submit(function () {

                    var this_master = jQuery(this);

                    this_master.find('input[type="checkbox"]').each( function () {
                        var checkbox_this = jQuery(this);

                        if (checkbox_this.attr("id") !== "redirect_enable" && checkbox_this.attr("id") !== "redirect_404_enable" && checkbox_this.attr("id") !== "redirect_attachment" && checkbox_this.attr("id") !== "redirect_badbot") 
                        {
                            if( checkbox_this.is(":checked") == true ) {
                                checkbox_this.attr('value','1');
                            } else {
                                checkbox_this.prop('checked',true);  
                                checkbox_this.attr('value','0');
                            }
                        }
                    })
                })
            </script>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
function gryphon_expand_redirects() {
			$redirects = get_option('gryphon_301_redirects');
			$output = '';
            $cont = 0;
			if (!empty($redirects)) {
				foreach ($redirects as $request => $bundle[]) {
                    $bundle_values = array_values($bundle); 
                    $myValues = $bundle_values[$cont];
                    $cont = $cont + 1;
                    $array_my_values = array_values($myValues); 
                    $destination = $array_my_values[0];
                    $device = $array_my_values[1];
                    $active = $array_my_values[2];
                    $wildcard = $array_my_values[3];
                    
					$output .= '
					<tr>
						<td style="min-width:100px;"><input type="text" pattern="[/][^/].*" name="gryphon_301_redirects[request][]" value="'.$request.'" style="width:99%" /></td>
                        <td style="max-width:20px;text-align:center;vertical-align: middle;"><input type="checkbox" name="gryphon_301_redirects[wildcard][]" value="1" ';
                        if(isset($wildcard) && 
                           $wildcard === '1') 
                        {
                            $output .= ' checked';
                        }
                        $output .= '/></td>
						<td style="min-width:100px;"><input type="url" validator="url" name="gryphon_301_redirects[destination][]" value="'.$destination.'" style="width:99%;"/></td>
						<td style="max-width:20px;text-align: center;" ><span class="wpgryphon-delete"></span></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:180px;" name="gryphon_301_redirects[device][]">
                        <option value="All" ';
                        if($device === 'All')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>All</option>
                        <option value="Bot" ';
                        if($device === 'Bot')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Only Crawlers</option>
                        <option value="No-Bot" ';
                        if($device === 'No-Bot')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Excluding Crawlers</option>
                        <option value="Good-Bot" ';
                        if($device === 'Good-Bot')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Good Crawlers Only</option>
                        <option value="Bad-Bot" ';
                        if($device === 'Bad-Bot')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Bad Crawlers Only</option>
                        </select></td>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;"><input type="checkbox" name="gryphon_301_redirects[active][]" value="1" ';
                        if(isset($active) && 
                           $active === '1') 
                        {
                            $output .= ' checked';
                        }
                        $output .= '/></td>
					</tr>';
				}
			}
			return $output;
		}

?>
<?php

function fwd_seo_admin_title_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group2');
    do_settings_sections('seo_option_group2');
    $seo_Title_Settings = get_option('seo_Title_Settings', false);
    if (isset($seo_Title_Settings['seo_post_title'])) {
        $seo_post_title = esc_html(sanitize_text_field($seo_Title_Settings['seo_post_title']));
    } else {
        $seo_post_title = get_bloginfo('name');
    }
    if (isset($seo_Title_Settings['seo_home_desc'])) {
        $seo_home_desc = esc_html(sanitize_text_field($seo_Title_Settings['seo_home_desc']));
    } else {
        $seo_home_desc = get_bloginfo('description');
    }
    if (isset($seo_Title_Settings['seo_title_sep'])) {
        $seo_title_sep = esc_html(sanitize_text_field($seo_Title_Settings['seo_title_sep']));
    } else {
        $seo_title_sep = '-';
    }
    $seo_show_descript = $seo_Title_Settings['seo_show_descript'];
    if (isset($seo_Title_Settings['seo_page_title'])) {
        $seo_page_title = esc_html($seo_Title_Settings['seo_page_title']);
    } else {
        $seo_page_title = get_bloginfo('name');
    }
    
    


?><script>
                var seo_admin_json = {    
                    seo_post_title: '<?php
    echo $seo_post_title;
?>',
                    seo_home_desc: '<?php
    echo $seo_home_desc;
?>',
                    seo_title_sep: '<?php
    echo $seo_title_sep;
?>',
                    seo_page_title: '<?php
    echo $seo_page_title;
?>'
}
            </script>
            <script type="text/javascript">
    window.onload = titleChanged;
    function titleChanged()
    {
        if(jQuery('.checkbocs').is(":checked"))   
            jQuery(".titleHide").show();
        else
            jQuery(".titleHide").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <span class="gs-sub-heading"><b>Page Title Settings:</b></span><br/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Custom Home Page Title:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Google typically displays the first 50-60 characters of a title tag, or as many characters as will fit into a 512-pixel display. If you keep your titles under 55 characters, you can expect at least 95% of your titles to display properly. If you leave this field blank, the default value will be used.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Title_Settings[seo_page_title]" ng-model="settings.seo_page_title" ng-trim="false" size="68" placeholder="<?php
    echo get_bloginfo('name');
?>">
                <span class="form-help">{{settings.seo_page_title.length}} characters used. Try to not go above 55 characters for best SEO results.</span>
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Title Separator:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Although it has never been confirmed any real significative advantage of using one over the other or any negative impact on SEO for using different separator in the title tag of the page but it does attract eyeballs of visitors. Use |, -, <, > or *. If you leave this field blank, the default value will be used.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Title_Settings[seo_title_sep]" ng-model="settings.seo_title_sep" ng-trim="false" size="68" placeholder="-">
                <span class="form-help">{{settings.seo_title_sep.length}} characters used. Try to not go above 1 character for best SEO results.</span>
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Page Title Shown After Each Post's Title:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should your preffered text to be shown after the post title. Preferably, this should be the same with your Page Title, but you can set it to a custom name if you want. Keep this also under 55 characters. If you leave this field blank, the default value will be used.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Title_Settings[seo_post_title]" ng-model="settings.seo_post_title" size="68" placeholder="<?php
    echo get_bloginfo('name');
?>">
                <span class="form-help">{{settings.seo_post_title.length}} characters used. Try to not go above 55 characters for best SEO results.</span>
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
            <input type="checkbox" class="checkbocs" id="seo_show_descript" onclick="titleChanged()" name="seo_Title_Settings[seo_show_descript]"<?php
            if ($seo_show_descript == 'on')
                echo ' checked ';
        ?>>
                Show Description Meta Tag
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                    <?php
            echo "This is one of the most important meta tags for SEO. Leave this check box checked, unless you understand the consequences of it's unchecking.";
        ?>
                        </div>
                    </div>
        <br/>
        <div class="titleHide">
                <div>
                    Home Page Description:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add the description you want to appear in the description meta tag of your home page. If you leave this field blank, the default value will be used.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Title_Settings[seo_home_desc]" ng-model="settings.seo_home_desc" ng-trim="false" size="68" placeholder="<?php
    echo get_bloginfo('description');
?>">
                <span class="form-help">{{settings.seo_home_desc.length}} characters used. Try to not go above 160 characters for best SEO results.</span>
            </div>
            </div>
        </div>
    </div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}

function fwd_seo_custom_theme_separator()
{
    $seo_Title_Settings = get_option('seo_Title_Settings', false);
    if (isset($seo_Title_Settings['seo_title_sep'])) {
        $seo_title_sep = esc_html(sanitize_text_field($seo_Title_Settings['seo_title_sep']));
    } else {
        $seo_title_sep = "-";
    }
    if ($seo_title_sep == '') {
        $seo_title_sep = '-';
    }
    echo $output;
    return $seo_title_sep;
}
add_filter('document_title_parts', 'fwd_seo_custom_theme_titles', PHP_INT_MAX);
add_filter('document_title_separator', 'fwd_seo_custom_theme_separator');
//new api
function fwd_seo_custom_theme_titles($parts)
{
    $seo_Title_Settings = get_option('seo_Title_Settings', false);
    if (isset($seo_Title_Settings['seo_post_title'])) {
        $seo_post_title = esc_html(sanitize_text_field($seo_Title_Settings['seo_post_title']));
    } else {
        $seo_post_title = get_bloginfo('name');
    }
    if ($seo_post_title == '') {
        $seo_post_title = get_bloginfo('name');
    }
    if (isset($seo_Title_Settings['seo_home_desc'])) {
        $seo_home_desc = esc_html(sanitize_text_field($seo_Title_Settings['seo_home_desc']));
    } else {
        $seo_home_desc = get_bloginfo('description', 'display');
    }
    if ($seo_home_desc == '') {
        $seo_home_desc = get_bloginfo('description', 'display');
    }
    if (isset($seo_Title_Settings['seo_page_title'])) {
        $seo_page_title = esc_html(sanitize_text_field($seo_Title_Settings['seo_page_title']));
    } else {
        $seo_page_title = get_bloginfo('name');
    }
    if ($seo_page_title == '') {
        $seo_page_title = get_bloginfo('name');
    }
    if (is_single()) {
        $parts['tagline'] = $seo_post_title;
        $parts['title']   = get_the_title();
        $parts['site']    = '';
    } else {
        $parts['tagline'] = $seo_home_desc;
        $parts['title']   = $seo_page_title;
        $parts['site']    = '';
    }
    
    return $parts;
}
//old api
/*add_filter('wp_title', 'my_custom_title');
function my_custom_title( $title )
{
// Return my custom title
return sprintf("%s %s", $title, get_bloginfo('name'));
}*/
?>
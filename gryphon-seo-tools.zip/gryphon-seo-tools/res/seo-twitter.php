<?php
function fwd_seo_twitter_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group5');
    do_settings_sections('seo_option_group5');
    $seo_Twitter_Settings = get_option('seo_Twitter_Settings', false);
    if (isset($seo_Twitter_Settings['seo_twitter_user'])) {
        $twitter_user = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_user']));
    } else {
        $twitter_user = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_creator'])) {
        $seo_twitter_creator = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_creator']));
    } else {
        $seo_twitter_creator = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image'])) {
        $twitter_image = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image']));
    } else {
        $twitter_image = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_alt'])) {
        $seo_twitter_image_alt = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image_alt']));
    } else {
        $seo_twitter_image_alt = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter'])) {
        $seo_twitter = $seo_Twitter_Settings['seo_twitter'];
    } else {
        $seo_twitter = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_title'])) {
        $seo_twitter_title = $seo_Twitter_Settings['seo_twitter_title'];
    } else {
        $seo_twitter_title = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_description'])) {
        $seo_twitter_description = $seo_Twitter_Settings['seo_twitter_description'];
    } else {
        $seo_twitter_description = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_sw'])) {
        $seo_twitter_image_sw = $seo_Twitter_Settings['seo_twitter_image_sw'];
    } else {
        $seo_twitter_image_sw = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_type'])) {
        $seo_twitter_type = $seo_Twitter_Settings['seo_twitter_type'];
    } else {
        $seo_twitter_type = 'summary';
    }
?><script>
                var seo_admin_json = {    
                    twitter_user: '<?php
    echo $twitter_user;
?>',
                    seo_twitter_creator: '<?php
    echo $seo_twitter_creator;
?>',
                    twitter_page_image: '<?php
    echo $twitter_image;
?>',
                    seo_twitter_image_alt: '<?php
    echo $seo_twitter_image_alt;
?>',
                    seo_twitter_type: '<?php
    echo $seo_twitter_type;
?>'
                    }
            </script>
            <script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('#tw_image_button').click(function(){
				tb_show('',"media-upload.php?type=image&TB_iframe=true");
			});
			
		});
	</script>
    <script type="text/javascript">
    window.onload = valueChanged;
    function valueChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".twitterHide").show();
        else
            jQuery(".twitterHide").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Twitter Meta Tags:</b></span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "With Twitter Cards, you can attach rich photos, videos and media experience to Tweets that drive traffic to your website.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_twitter" name="seo_Twitter_Settings[seo_twitter]" onchange="valueChanged()"<?php
    if ($seo_twitter == 'on')
        echo ' checked ';
?>>
                            <label for="seo_twitter"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
        <div class="twitterHide">
        <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Twitter User Name:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The Twitter @username the card should be attributed to. Required for Twitter Card analytics. (enter name with or without @ symbol).";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Twitter_Settings[seo_twitter_user]" ng-model="settings.twitter_user" placeholder="your_Twitter_account" size="68">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Twitter Creator Name:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Username of content creator(enter name with or without @ symbol).";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Twitter_Settings[seo_twitter_creator]" ng-model="settings.seo_twitter_creator" size="68" placeholder="creator_Twitter_account">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Twitter Default Image Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "URL of image to use in the card when no image is available (posts without image or front page).";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Twitter_Settings[seo_twitter_image]" ng-model="settings.twitter_page_image" placeholder="http://www.mydomain.com/my_image.jpg" size="68">
                <input id="tw_image_button" class="button" type="button" value="Choose image" />
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Twitter Default Image Description:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Description of image to use in the card when no image is available (posts without image or front page).";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Twitter_Settings[seo_twitter_image_alt]" ng-model="settings.seo_twitter_image_alt" placeholder="Your image description" size="68">
            </div>
        </div>
        <span class="gs-sub-heading"><b>Twitter Card Title:</b></span>
        <input type="checkbox" id="seo_twitter_title" name="seo_Twitter_Settings[seo_twitter_title]"<?php
    if ($seo_twitter_title == 'on')
        echo ' checked ';
?>>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Title of content (max 70 characters for best SEO results).";
?>
                        </div>
                    </div>
                    <br/>
        <span class="gs-sub-heading"><b>Twitter Description:</b></span>
        <input type="checkbox" id="seo_twitter_description" name="seo_Twitter_Settings[seo_twitter_description]"<?php
    if ($seo_twitter_description == 'on')
        echo ' checked ';
?>>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Description of content (maximum 200 characters for best SEO results)";
?>
                        </div>
                    </div>
                    <br/>
        <span class="gs-sub-heading"><b>Twitter Image:</b></span>
        <input type="checkbox" id="seo_twitter_image_sw" name="seo_Twitter_Settings[seo_twitter_image_sw]"<?php
    if ($seo_twitter_image_sw == 'on')
        echo ' checked ';
?>>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "URL of image to use in the card. This plugin will automatically detect and add the image link to this meta tag.";
?>
                        </div>
                    </div>
    <br/>
        <span class="gs-sub-heading">Twitter Card Type:&nbsp;&nbsp;&nbsp;</span>
        
        <label><input type="radio" name="seo_Twitter_Settings[seo_twitter_type]" value="summary"
            id="radio_tw_card" ng-model="settings.seo_twitter_type"> Summary Card</label>&nbsp; 
        <label><input type="radio" name="seo_Twitter_Settings[seo_twitter_type]" value="summary_large_image" 
            id="radio_tw_large" ng-model="settings.seo_twitter_type"> Summary Card With Large Image</label>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "You can this option to set the Twitter Card Type that will be used by default for all content. You can find information on Twitter Card Types <a href='https://dev.twitter.com/cards/overview' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
    </div>
    </div>
    
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
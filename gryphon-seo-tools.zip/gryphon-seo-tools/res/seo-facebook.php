<?php
function fwd_seo_facebook_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group7');
    do_settings_sections('seo_option_group7');
    $seo_Facebook_Settings = get_option('seo_Facebook_Settings', false);
    if (isset($seo_Facebook_Settings['seo_facebook_image'])) {
        $facebook_image = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_image']));
    } else {
        $facebook_image = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_author'])) {
        $seo_facebook_author = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_author']));
    } else {
        $seo_facebook_author = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_publisher'])) {
        $seo_facebook_publisher = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_publisher']));
    } else {
        $seo_facebook_publisher = '';
    }
    $seo_facebook = $seo_Facebook_Settings['seo_facebook'];
    $seo_facebook_locale = $seo_Facebook_Settings['seo_facebook_locale'];
    if (isset($seo_Facebook_Settings['seo_facebook_app_id'])) {
        $seo_facebook_app_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_app_id']));
    } else {
        $seo_facebook_app_id = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_admin_id'])) {
        $seo_facebook_admin_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_admin_id']));
    } else {
        $seo_facebook_admin_id = '';
    }
    $seo_facebook_show_site_name = $seo_Facebook_Settings['seo_facebook_show_site_name'];
    $seo_facebook_show_title = $seo_Facebook_Settings['seo_facebook_show_title'];
    $seo_facebook_show_url = $seo_Facebook_Settings['seo_facebook_show_url'];
    $seo_facebook_show_type = $seo_Facebook_Settings['seo_facebook_show_type'];
    $seo_facebook_show_times = $seo_Facebook_Settings['seo_facebook_show_times'];
    $seo_facebook_show_image = $seo_Facebook_Settings['seo_facebook_show_image'];
    $seo_facebook_show_description = $seo_Facebook_Settings['seo_facebook_show_description'];
    $seo_facebook_show_sections = $seo_Facebook_Settings['seo_facebook_show_sections'];
    if (isset($seo_Facebook_Settings['seo_facebook_type'])) {
        $seo_facebook_type = $seo_Facebook_Settings['seo_facebook_type'];
    } else {
        $seo_facebook_type = 'Website';
    }
?><script>
                var seo_admin_json = {    
                    facebook_page_image: '<?php
    echo $facebook_image;
?>',
                    facebook_app_id: parseInt('<?php
    echo $seo_facebook_app_id;
?>', 10),
                    
                    facebook_admin_id: parseInt('<?php
    echo $seo_facebook_admin_id;
?>', 10),
                    seo_facebook_type: '<?php
    echo $seo_facebook_type;
?>',
                    seo_facebook_author: '<?php
    echo $seo_facebook_author;
?>',
                    seo_facebook_publisher: '<?php
    echo $seo_facebook_publisher;
?>'}
            </script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()"> 
                <div class="gs_admin_main_table"><?php
    
?>
<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('#fb_image_button').click(function(){
				tb_show('',"media-upload.php?type=image&TB_iframe=true");
			});
			
		});
	</script>
    <script type="text/javascript">
    window.onload = fbChanged;
    function fbChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".fbHide").show();
        else
            jQuery(".fbHide").hide();
    }
</script>
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Facebook Meta Tags:</b></span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Facebook requests or “scrapes” the URL you’re sharing and gets the data it displays from meta tags in the <head> section of the page. To control how your page is shared on Facebook you should use OpenGraph tags.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="seo_facebook" name="seo_Facebook_Settings[seo_facebook]" onchange="fbChanged()" <?php
    if ($seo_facebook == 'on')
        echo ' checked ';
?>>
                            <label for="seo_facebook"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <div class="fbHide">
                    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook App Id:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enter your Facebook App ID here. Information about how to get your Facebook App ID can be found at <a href='https://developers.facebook.com/docs/apps/register' target='_blank'>https://developers.facebook.com/docs/apps/register</a>";
?>
                        </div>
                    </div>
                    <input type="number" name="seo_Facebook_Settings[seo_facebook_app_id]" ng-model="settings.facebook_app_id" min="1000000000000000" max="9999999999999999" placeholder="1234567890123456">
                </div>          
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook Admin Id:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enter your Facebook Admin ID here. You can look up your Facebook  ID using this tool <a href='http://findmyfbid.com/' target='_blank'>http://findmyfbid.com/</a>";
?>
                        </div>
                    </div>
                    <input type="number" name="seo_Facebook_Settings[seo_facebook_admin_id]" ng-model="settings.facebook_admin_id" min="1000000000000000" max="9999999999999999" placeholder="1234567890123456">
                </div>
            </div>
        </div>
        <input type="checkbox" id="seo_facebook_locale" name="seo_Facebook_Settings[seo_facebook_locale]"<?php
    if ($seo_facebook_locale == 'on')
        echo ' checked ';
?>>
        Facebook Locale Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The locale the OpenGraph tags are marked up in. The format of the tag is: language_TERRITORY (ex:en_US). This plugin will autodetect and set the right locale tag for you.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_site_name" name="seo_Facebook_Settings[seo_facebook_show_site_name]"<?php
    if ($seo_facebook_show_site_name == 'on')
        echo ' checked ';
?>>
        Facebook Site Name Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "If your object is part of a larger web site, the name which should be displayed for the overall site. e.g., 'IMDb'. This plugin will autodetect and set the right name tag for you.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_title" name="seo_Facebook_Settings[seo_facebook_show_title]"<?php
    if ($seo_facebook_show_title == 'on')
        echo ' checked ';
?>>
        Facebook Title Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The title of your object as it should appear within the graph, e.g., 'The Rock'. This plugin will autodetect and set the right title tag for you. Do not disable this, unless you understand that it will break Facebook meta tags.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_url" name="seo_Facebook_Settings[seo_facebook_show_url]"<?php
    if ($seo_facebook_show_url == 'on')
        echo ' checked ';
?>>
        Facebook URL Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The canonical URL of your object that will be used as its permanent ID in the graph, e.g., 'http://www.imdb.com/title/tt0117500/'. This plugin will autodetect and set the right url tag for you.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_type" name="seo_Facebook_Settings[seo_facebook_show_type]"<?php
    if ($seo_facebook_show_type == 'on')
        echo ' checked ';
?>>
        Facebook Type Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The type of your object, e.g., 'video.movie', 'website' or 'article'. This plugin will autodetect and set the right type tag for you.";
?>
                        </div>
                    </div>
        <br/>
        <span class="gs-sub-heading">Home Page Type:&nbsp;&nbsp;&nbsp;</span>
        <label><input type="radio" name="seo_Facebook_Settings[seo_facebook_type]" value="Website"
            id="radio_fb_website" ng-model="settings.seo_facebook_type"> Website</label>&nbsp; 
        <label><input type="radio" name="seo_Facebook_Settings[seo_facebook_type]" value="Blog" 
            id="radio_fb_blog" ng-model="settings.seo_facebook_type"> Blog</label>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Set this to the appropriate value. 'Blog' if your webpage is a blog, 'Website' otherwise.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_times" name="seo_Facebook_Settings[seo_facebook_show_times]"<?php
    if ($seo_facebook_show_times == 'on')
        echo ' checked ';
?>>
        Show Date Published/Updated (only for articles)
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Adds information about when the article was first published or last changed. This plugin will autodetect and set the right timestamps for you.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_sections" name="seo_Facebook_Settings[seo_facebook_show_sections]"<?php
    if ($seo_facebook_show_sections == 'on')
        echo ' checked ';
?>>
        Show Article Sections (same as categories)
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The section tag should contain a high-level section name. E.g. 'Technology'. This plugin will autodetect and set the right section for you, from post category.";
?>
                        </div>
                    </div>
        <br/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook Publisher Page Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "By entering the URL for your valid Facebook Page here, you can link articles to your Facebook Page. This only works for content where the Object Type is set to Article.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Facebook_Settings[seo_facebook_publisher]" ng-model="settings.seo_facebook_publisher" placeholder="http://www.facebook.com/publisher_page" size="68">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook Author Page Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "This option will use the Facebook profile URL entered in the Edit User screen as the Article:Author tag. This links articles authored by that user to their Facebook profile. This only works for content where the Object Type is set to Article.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Facebook_Settings[seo_facebook_author]" ng-model="settings.seo_facebook_author" placeholder="http://www.facebook.com/author_page" size="68">
            </div>
        </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_description" name="seo_Facebook_Settings[seo_facebook_show_description]"<?php
    if ($seo_facebook_show_description == 'on')
        echo ' checked ';
?>>
        Include Description Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "A one to two sentence description of your object. This plugin will autodetect and set the right description for you, based on the post excerpt or post content.";
?>
                        </div>
                    </div>
        <br/>
        <input type="checkbox" id="seo_facebook_show_image" name="seo_Facebook_Settings[seo_facebook_show_image]"<?php
    if ($seo_facebook_show_image == 'on')
        echo ' checked ';
?>>
        Include Image Tag
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "An image URL which should represent your object within the graph. This plugin will autodetect and set the right image tag for you, based on post content.";
?>
                        </div>
                    </div>
        <br/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook Page Image Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Select the default image to be shown in the open graph tags, if a post has no images or on the main page.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Facebook_Settings[seo_facebook_image]" ng-model="settings.facebook_page_image" placeholder="http://www.mydomain.com/my_image.jpg" size="68">
                <input id="fb_image_button" class="button" type="button" value="Choose image" />
            </div>
        </div>
        </div>
</div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
<?php
    set_time_limit(60*60*60*24);
                                       
    define ("AGENT", "Mozilla/5.0 (compatible; FWD SEO Crawler 1.0)");
    define ("NL", "<br>");
    $scanned = '';

function write ($output)
{
    echo($output);
    flush();
    ob_flush(); 
}    

function GetPage ($url)
{
    $ch = curl_init ($url);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_USERAGENT, AGENT);

    $data = curl_exec($ch);

    curl_close($ch);

    return $data;
}

function GetQuotedUrl ($str)
{
    $quote = substr ($str, 0, 1);
    if (($quote != "\"") && ($quote != "'"))
    {
        return $str;
    }                                                 

    $ret = "";
    $len = strlen ($str);    
    for ($i = 1; $i < $len; $i++)
    {
        $ch = substr ($str, $i, 1);
        
        if ($ch == $quote) break;

        $ret .= $ch;
    }
    
    return $ret;
}

function GetHREFValue ($anchor)
{
    $split1  = explode ("href=", $anchor);
    $split2 = explode (">", $split1[1]);
    $href_string = $split2[0];

    $first_ch = substr ($href_string, 0, 1);
    if ($first_ch == "\"" || $first_ch == "'")
    {
        $url = GetQuotedUrl ($href_string);
    }
    else
    {
        $spaces_split = explode (" ", $href_string);
        $url          = $spaces_split[0];
    }
    return $url;
}

function GetEffectiveURL ($url)
{
    $ch = curl_init ($url);

    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_USERAGENT, AGENT);
    curl_exec($ch);

    $effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    return $effective_url;
}

function ValidateURL ($url_base, $url, $site_scheme, $site_host)
{
    global $scanned;
        
    $parsed_url = parse_url ($url);
        
    $scheme = $parsed_url["scheme"];
    
    if (($scheme != $site_scheme) && ($scheme != ""))
    {
        //write("Not site scheme: $url" . NL);
        return false;
    }
    
    $host = $parsed_url["host"];
    //external links?
    if (($host != $site_host) && ($host != ""))
    {
        //write("Not site host: $url" . NL);
        return false;
    }

    if ($host == "")
    {
        if (substr ($url, 0, 1) == '#')
        {
            //write("Skip page anchor: $url" . NL);
            return false;
        }
    
        if (substr ($url, 0, 1) == '/')
        {
            $url = $site_scheme . "://" . $site_host . $url;
        }
        else
        {
        
            $path = parse_url ($url_base, PHP_URL_PATH);
            
            if (substr ($path, -1) == '/') 
            {
                $url = $site_scheme . "://" . $site_host . $path . $url;
            }
            else
            {
                $dirname = dirname ($path);

                if ($dirname[0] != '/')
                {
                    $dirname = "/$dirname";
                }
    
                if (substr ($dirname, -1) != '/')
                {
                    $dirname = "$dirname/";
                }

                $url = $site_scheme . "://" . $site_host . $dirname . $url;
            }
        }
    }

    $url = GetEffectiveURL ($url); 

    if (in_array ($url, $scanned))
    {
        //write("Already scanned: $url" . NL);
        return false;
    }
   
    return $url;
}

function Scan ($url, $site_scheme, $site_host)
{
    global $scanned; 
    $scanned[] = $url;
    if (substr ($url, -2) == "//") 
    {
        $url = substr ($url, 0, -2);
    }
    if (substr ($url, -1) == "/") 
    {
        $url = substr ($url, 0, -1);
    }

    write("Scan $url" . NL);

    $headers = get_headers ($url, 1);

    if (strpos ($headers[0], "301") == true)
    {   
        $url = $headers["Location"];
        $scanned[] = $url;
        $headers = get_headers ($url, 1);
        write("Redirected to: $url" . NL);
    }
    else if (strpos ($headers[0], "200") == false)
    {
        write("Skip HTTP code $headers[0]: $url" . NL);
        return false;
    }

    if (is_array ($headers["Content-Type"]))
    {
        $content = explode (";", $headers["Content-Type"][0]);
    }
    else
    {
        $content = explode (";", $headers["Content-Type"]);
    }
    
    $content_type = trim (strtolower ($content[0]));

    if ($content_type != "text/html") 
    {
        if ($content_type == "")
        {
            //write("Info: Content-Type is not sent by the web server. Change " .
                //"'IGNORE_EMPTY_CONTENT_TYPE' to 'true' in the sitemap script " .
                //"to scan those pages too." . NL);
        }
        else
        {
            //write("Info: $url is not a website: $content[0]" . NL);
        }
        return false;
    }

    $html = GetPage ($url);
    $html = trim ($html);
    if ($html == "") return true;
    
    $html = str_replace ("\r", " ", $html);
    $html = str_replace ("\n", " ", $html);
    $html = str_replace ("\t", " ", $html);
    $html = str_replace ("<A ", "<a ", $html);
    $html = substr ($html, strpos ("<a ", $html));

    $a1   = explode ("<a ", $html);
    foreach ($a1 as $next_url)
    {
        $next_url = trim ($next_url);
        
        if ($next_url == "") continue; 
        
        $next_url = GetHREFValue ($next_url); 

        $next_url = ValidateURL ($url, $next_url, $site_scheme, $site_host);

        if ($next_url == false) 
        {
            continue;
        }
        Scan ($next_url, $site_scheme, $site_host);
    }

    return true;
}

function seo_crawler_main()
{
    ob_implicit_flush(true);
    if (ob_get_level() == 0) ob_start();

    ?>
    <div class="gs_popuptype_holder">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group9');
    do_settings_sections('seo_option_group9');
    $seo_Crawler_Settings = get_option('seo_Crawler_Settings', false);
    if (isset($seo_Crawler_Settings['seo_crawl_start'])) {
        $seo_crawl_start = $seo_Crawler_Settings['seo_crawl_start'];
    } else {
        $seo_crawl_start = get_home_url();
    }
    $site_scheme = parse_url ($seo_crawl_start, PHP_URL_SCHEME);
    $site_host = parse_url ($seo_crawl_start, PHP_URL_HOST);
?><script>
                var seo_admin_json = {    
                    seo_crawl_start: '<?php
    echo $seo_crawl_start;
?>'}
            </script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_radio_related_row">
                    <div class="gs_radio_related_cell">
                        <div>
                            Crawler starting link:
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                    <?php
                echo "Here you should add a valid link to start crawling from.";
        ?>
                                </div>
                            </div>
                        </div>
                        <input type="url" validator="url" name="seo_Crawler_Settings[seo_crawl_start]" ng-model="settings.seo_crawl_start" size="68">
                    </div>
                </div>
                <br/>
                <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
                <br/>
                <div>
                    <?php
                        global $scanned;                  
                        error_reporting (E_ERROR | E_WARNING | E_PARSE);     
                        $scanned = array();
                        Scan (GetEffectiveURL ($seo_crawl_start), $site_scheme, $site_host);
                        write("Done." . NL);
                        ?>
                </div>   
    </div>
    </form>
</div>
</div>
     <?php
    ob_end_flush();
    ob_implicit_flush(false);
    }
    ?>
<?php
set_time_limit(60 * 60 * 60 * 24);

define("AGENT", "Mozilla/5.0 (compatible; KISDED SEO Crawler 1.0)");
define("NL", "<br>");
$scanned = '';

function write($output)
{
    echo ($output);
    flush();
    ob_flush();
}
function write_message($output)
{
    echo ("<p style='color:green;margin:0;'>[MESSAGE] ".$output."</p>");
    flush();
    ob_flush();
}
function write_warning($output)
{
    echo ("<p style='color:#FDE541;margin:0;'>[WARNING] ".$output."</p>");
    flush();
    ob_flush();
}
function write_error($output)
{
    echo ("<p style='color:red;margin:0;'>[ERROR] ".$output."</p>");
    flush();
    ob_flush();
}

function GetPage($url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, AGENT);
    
    $data = curl_exec($ch);
    
    curl_close($ch);
    
    return $data;
}

function GetQuotedUrl($str)
{
    $quote = substr($str, 0, 1);
    if (($quote != "\"") && ($quote != "'")) {
        return $str;
    }
    
    $ret = "";
    $len = strlen($str);
    for ($i = 1; $i < $len; $i++) {
        $ch = substr($str, $i, 1);
        
        if ($ch == $quote)
            break;
        
        $ret .= $ch;
    }
    
    return $ret;
}

function GetHREFValue($anchor)
{
    $split1      = explode("href=", $anchor);
    $split2      = explode(">", $split1[1]);
    $href_string = $split2[0];
    
    $first_ch = substr($href_string, 0, 1);
    if ($first_ch == "\"" || $first_ch == "'") {
        $url = GetQuotedUrl($href_string);
    } else {
        $spaces_split = explode(" ", $href_string);
        $url          = $spaces_split[0];
    }
    return $url;
}

function GetEffectiveURL($url)
{
    $ch = curl_init($url);
    
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, AGENT);
    curl_exec($ch);
    
    $effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    
    return $effective_url;
}

function ValidateURL($url_base, $url, $site_scheme, $site_host)
{
    global $scanned;
    
    $parsed_url = parse_url($url);
    
    $scheme = $parsed_url["scheme"];
    
    if (($scheme != $site_scheme) && ($scheme != "")) {
        //write_message("Not site scheme: $url");
        //return false;!!!
    }
    
    
    $host = $parsed_url["host"];

    if (($host != $site_host) && ($host != "")) {
        //write_message("Not site host: $url");
        //return false;!!!
    }
    
    
    if ($host == "") {
        if (substr($url, 0, 1) == '#') {
            //write_message("Skip page anchor: $url");
            return false;
        }
        
        if (substr($url, 0, 1) == '/') {
            $url = $site_scheme . "://" . $site_host . $url;
        } else {
            
            $path = parse_url($url_base, PHP_URL_PATH);
            
            if (substr($path, -1) == '/') {
                $url = $site_scheme . "://" . $site_host . $path . $url;
            } else {
                $dirname = dirname($path);
                
                if ($dirname[0] != '/') {
                    $dirname = "/$dirname";
                }
                
                if (substr($dirname, -1) != '/') {
                    $dirname = "$dirname/";
                }
                
                $url = $site_scheme . "://" . $site_host . $dirname . $url;
            }
        }
    }
    
    $url = GetEffectiveURL($url);
    
    if (in_array($url, $scanned)) {
        //write_message("Already scanned: $url");
        return false;
    }
    
    return $url;
}

function Scan($url, $site_scheme, $site_host, $recurse, $rootUrl)
{
    global $scanned;
    $scanned[] = $url;
    if (substr($url, -2) == "//") {
        $url = substr($url, 0, -2);
    }
    if (substr($url, -1) == "/") {
        $url = substr($url, 0, -1);
    }
    
    write_message("Scan $url coming from $rootUrl");
    if(substr( $url, 0, 4 ) != "http")
    {
        return false;
    }
    $headers = get_headers($url, 1);
    if (strpos($headers[0], "301") == true) {
        $url       = $headers["Location"];
        $scanned[] = $url;
        $headers   = get_headers($url, 1);
        write_message("Redirected to: $url (HTTP code 301)");
    } else if (strpos($headers[0], "302") == true) {
        write_warning("Found HTTP code $headers[0]: $url in page $rootUrl. If this page is moved permanently, replace this code with 301 for best SEO.");
        return false;
    } else if (strpos($headers[0], "404") == true) {
        write_error("Found HTTP code $headers[0]: $url in page $rootUrl. The link is broken! Remove it ASAP!");
        return false;
    } else if (strpos($headers[0], "500") == true) {
        write_error("Found HTTP code $headers[0]: $url in page $rootUrl. The URL contains a server error! Remove it ASAP!");
        return false;
    } else if (strpos($headers[0], "503") == true) {
        write_error("Found HTTP code $headers[0]: $url in page $rootUrl. The URL contains a server error! Remove it ASAP!");
        return false;
    } else if (strpos($headers[0], "200") == false) {
        write_warning("Skip HTTP code $headers[0]: $url in page $rootUrl");
        return false;
    }
    
    if (is_array($headers["Content-Type"])) {
        $content = explode(";", $headers["Content-Type"][0]);
    } else {
        $content = explode(";", $headers["Content-Type"]);
    }
    
    $content_type = trim(strtolower($content[0]));
    
    if ($content_type != "text/html") {
        if ($content_type == "") {
            write_warning("$url - Content-Type is not sent by the web server - found on page $rootUrl.");
        } else {
            write_message("$url is not a website: $content[0] - found on page $rootUrl.");
        }
        return false;
    }
    if($recurse == true)
    {
        $html = GetPage($url);
        $html = trim($html);
        if ($html == "")
            return true;
        
        $html = str_replace("\r", " ", $html);
        $html = str_replace("\n", " ", $html);
        $html = str_replace("\t", " ", $html);
        $html = str_replace("<A ", "<a ", $html);
        $html = substr($html, strpos("<a ", $html));
        
        $a1 = explode("<a ", $html);
        foreach ($a1 as $next_url) {
            $next_url = trim($next_url);
            
            if ($next_url == "")
                continue;
            
            $next_url = GetHREFValue($next_url);
            //in plus
            $recurse = true;
            $parsed_url = parse_url($next_url);
    
            $scheme = $parsed_url["scheme"];
            
            if (($scheme != $site_scheme) && ($scheme != "")) {
                //write_message("Not site scheme: $next_url");
                $recurse = false;
            }
            
            
            $host = $parsed_url["host"];

            if (($host != $site_host) && ($host != "")) {
                //write_message("Not site host: $next_url");
                $recurse = false;
            }
            
            $next_url = ValidateURL($url, $next_url, $site_scheme, $site_host);
            
            if ($next_url == false) {
                continue;
            }
            Scan($next_url, $site_scheme, $site_host, $recurse, $url);
        }
    }
    
    return true;
}

function seo_crawler_main()
{
    ob_implicit_flush(true);
    if (ob_get_level() == 0)
        ob_start();
    
?>
    <div class="gs_popuptype_holder">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    $seo_crawl_start = get_home_url();
    $site_scheme = parse_url($seo_crawl_start, PHP_URL_SCHEME);
    $site_host   = parse_url($seo_crawl_start, PHP_URL_HOST);
?><script>
                var seo_admin_json = {    
                    seo_crawl_start: '<?php
    echo $seo_crawl_start;
?>'}
            </script>
            <?php
    $query_arg = add_query_arg('step', 'one', $_SERVER['REQUEST_URI']);
    if (0 !== get_query_var('step') && 'one' !== get_query_var('step')) {
?>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
            <input type="button" name="stopPr" id="stopPr" value="Stop Crawler" onclick="location.href = '<?php echo admin_url();?>?page=fwd_seo_admin_settings';"/><br/>
            <table><tr><td><p><b>CRAWLED SITES, starting from your index page (check for <span style='color:#FDE541;margin:0;'>warning - yellow</span> and <span style='color:red;margin:0;'>error - red</span> messages and try to correct them):</b></p></td><td>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "A status code is a piece of information returned by a web server in the HTTP response headers, after receiving a request for a file, such as a web page.
If the server was able to process the request for the web page, the server will usually return a 200 HTTP status, along with the requested web page. This tells the web browser, or crawler, that the request was completed successfully.. Information about status codes can be found at <a href='https://en.wikipedia.org/wiki/List_of_HTTP_status_codes' target='_blank'>https://en.wikipedia.org/wiki/List_of_HTTP_status_codes</a>";
?>
                        </div>
                    </div>
                <div></td></tr></table>
                    <?php
        global $scanned;
        $scanned = array();
        Scan(GetEffectiveURL($seo_crawl_start), $site_scheme, $site_host, true, get_home_url());
        write_message("<b>CRAWLING FINISHED.</b>");
?>
                </div>   
    </div>
    <?php
    }
?>
    </form>
</div>
</div>
     <?php
    ob_end_flush();
    ob_implicit_flush(false);
}
?>
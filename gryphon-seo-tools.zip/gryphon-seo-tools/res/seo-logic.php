<?php
function fetch_locale($match = '')
{
    if (empty($match))
        $match = get_locale();
    $match_len     = strlen($match);
    $valid_locales = (array) fb_locales();
    $default       = 'en_US';
    if ($match_len > 5) {
        $match     = substr($match, 0, 5);
        $match_len = 5;
    }
    if (5 === $match_len) {
        if (in_array($match, $valid_locales))
            return $match;
        $match     = substr($match, 0, 2);
        $match_len = 2;
    }
    if (2 === $match_len) {
        $locale_keys = (array) language_keys();
        if ($key = array_search($match, $locale_keys)) {
            return $valid_locales[$key];
        }
    }
    return $default;
}

function seo_fb_open_graph_add_opengraph_namespace($output)
{
    if (stristr($output, 'xmlns:og')) {
    } else {
        $output = $output . ' xmlns:og="http://ogp.me/ns#"';
    }
    if (stristr($output, 'xmlns:fb')) {
    } else {
        $output = $output . ' xmlns:fb="http://ogp.me/ns/fb#"';
    }
    return $output;
}
add_filter('language_attributes', 'seo_fb_open_graph_add_opengraph_namespace', 9999);

function prepend_at_symbol($twitter_profile)
{
    if ('@' !== $twitter_profile[0]) {
        $twitter_profile = '@' . $twitter_profile;
    }
    return $twitter_profile;
}

function get_open_graph_post_image($default_image = '')
{
    $post      = get_post();
    $thumbdone = false;
    $fb_image  = '';
    if (is_attachment()) {
        if ($temp = wp_get_attachment_image_src(null, 'full')) {
            $fb_image = trim($temp[0]);
            if (trim($fb_image) != '') {
                $thumbdone = true;
            }
        }
    }
    if (!$thumbdone) {
        if (function_exists('get_post_thumbnail_id')) {
            if ($id_attachment = get_post_thumbnail_id($post->ID)) {
                $fb_image  = wp_get_attachment_url($id_attachment, false);
                $thumbdone = true;
            }
        }
    }
    if (!$thumbdone) {
        $imgreg = '/<img .*src=["\']([^ ^"^\']*)["\']/';
        preg_match_all($imgreg, trim($post->post_content), $matches);
        if ($matches[1]) {
            $imagetemp = false;
            foreach ($matches[1] as $image) {
                $pos = strpos($image, site_url());
                if ($pos === false) {
                    if (stristr($image, 'http://') || stristr($image, 'https://') || mb_substr($image, 0, 2) == '//') {
                        if (mb_substr($image, 0, 2) == '//')
                            $image = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https:' : 'http:') . $image;
                        $imagetemp = $image;
                    } else {
                        $imagetemp = site_url() . $image;
                    }
                } else {
                    $imagetemp = $image;
                }
                if ($imagetemp) {
                    $fb_image  = $imagetemp;
                    $thumbdone = true;
                    break;
                }
            }
        }
    }
    if (!$thumbdone) {
        $images = get_posts(array(
            'post_type' => 'attachment',
            'numberposts' => -1,
            'post_status' => null,
            'order' => 'ASC',
            'orderby' => 'menu_order',
            'post_mime_type' => 'image',
            'post_parent' => $post->ID
        ));
        if ($images) {
            foreach ($images as $image) {
                $imagetemp = wp_get_attachment_url($image->ID, false);
                $fb_image  = $imagetemp;
                $thumbdone = true;
                break;
            }
        }
    }
    if (!$thumbdone) {
        $fb_image = $default_image;
    }
    return $fb_image;
}

function seo_get_page_type()
{
    global $wp_query;
    $loop = 'notfound';
    if ($wp_query->is_page) {
        $loop = is_front_page() ? 'front' : 'page';
    } elseif ($wp_query->is_home) {
        $loop = 'home';
    } elseif ($wp_query->is_single) {
        $loop = ($wp_query->is_attachment) ? 'attachment' : 'single';
    } elseif ($wp_query->is_category) {
        $loop = 'category';
    } elseif ($wp_query->is_tag) {
        $loop = 'tag';
    } elseif ($wp_query->is_tax) {
        $loop = 'tax';
    } elseif ($wp_query->is_archive) {
        if ($wp_query->is_day) {
            $loop = 'archive';
        } elseif ($wp_query->is_month) {
            $loop = 'archive';
        } elseif ($wp_query->is_year) {
            $loop = 'archive';
        } elseif ($wp_query->is_author) {
            $loop = 'archive';
        } else {
            $loop = 'archive';
        }
    } elseif ($wp_query->is_search) {
        $loop = 'search';
    } elseif ($wp_query->is_404) {
        $loop = 'notfound';
    }
    return $loop;
}
function seo_add_ldjsons()
{
    $type = json_encode('organization');
    $name = json_encode('name');
    $url  = json_encode(esc_url(home_url('/')));
    
    $logo = '';
    $icon = get_site_icon_url();
    if ($icon) {
        $logourl = esc_url_raw($icon);
        $logo    = json_encode($logourl) . ',';
    }
    
    $comma    = ',';
    $sameurls = '';
    $args     = func_get_args();
    foreach ($args as $index => $arg) {
        if ($arg != "") {
            $sameurls .= json_encode($arg) . $comma;
        }
        unset($args[$index]);
    }
    $sameurls = rtrim($sameurls, $comma);
    
    $output = '<script type="application/ld+json">{"@context:"http:\/\/schema.org","@type":"' . $type . '","name":"' . $name . '","url":"' . $url . '","logo":"' . $logo . '","sameAs":[' . $sameurls . ']}</script>' . "\r\n";
    echo $output;
    $output2 = '<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","name":"' . $name . '","url":"' . $url . '"}</script>';
    echo $output2;
    $output3 = '<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","url":"' . $url . '","name":"' . $name . '","potentialAction":{"@type":"SearchAction","target":"' . $url . '?s={search_term_string}","query-input":"required name=search_term_string"}}</script>';
    echo $output3;
}

function debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}

add_action('wp_head', 'fwd_seo_main');
function fwd_seo_main()
{
    $seo_blog_description          = '';
    $seo_general_settings          = get_option('seo_General_Settings', false);
    $seo_Social_Links_Settings     = get_option('seo_Social_Links_Settings', false);
    $seo_Validation_Codes_Settings = get_option('seo_Validation_Codes_Settings', false);
    $seo_Twitter_Settings          = get_option('seo_Twitter_Settings', false);
    $seo_Common_Settings           = get_option('seo_Common_Settings', false);
    $seo_Google_Settings           = get_option('seo_Google_Settings', false);
    $seo_Facebook_Settings         = get_option('seo_Facebook_Settings', false);
    
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
    if (isset($seo_general_settings['seo_noindex_posts'])) {
        $seo_noindex_posts = $seo_general_settings['seo_noindex_posts'];
    } else {
        $seo_noindex_posts = '';
    }
    if (isset($seo_general_settings['seo_noindex_pages'])) {
        $seo_noindex_pages = $seo_general_settings['seo_noindex_pages'];
    } else {
        $seo_noindex_pages = '';
    }
    if (isset($seo_general_settings['seo_noindex_media'])) {
        $seo_noindex_media = $seo_general_settings['seo_noindex_media'];
    } else {
        $seo_noindex_media = '';
    }
    if (isset($seo_general_settings['seo_noindex_category'])) {
        $seo_noindex_category = $seo_general_settings['seo_noindex_category'];
    } else {
        $seo_noindex_category = '';
    }
    if (isset($seo_general_settings['seo_noindex_archive'])) {
        $seo_noindex_archive = $seo_general_settings['seo_noindex_archive'];
    } else {
        $seo_noindex_archive = '';
    }
    if (isset($seo_general_settings['seo_noindex_search'])) {
        $seo_noindex_search = $seo_general_settings['seo_noindex_search'];
    } else {
        $seo_noindex_search = '';
    }
    if (isset($seo_general_settings['seo_noindex_tax'])) {
        $seo_noindex_tax = $seo_general_settings['seo_noindex_tax'];
    } else {
        $seo_noindex_tax = '';
    }
    if (isset($seo_general_settings['seo_noindex_nf'])) {
        $seo_noindex_nf = $seo_general_settings['seo_noindex_nf'];
    } else {
        $seo_noindex_nf = '';
    }
    if (isset($seo_general_settings['seo_noindex_home'])) {
        $seo_noindex_home = $seo_general_settings['seo_noindex_home'];
    } else {
        $seo_noindex_home = '';
    }
    if (isset($seo_general_settings['seo_noindex_tag'])) {
        $seo_noindex_tag = $seo_general_settings['seo_noindex_tag'];
    } else {
        $seo_noindex_tag = '';
    }
    if (isset($seo_general_settings['seo_nofollow_category'])) {
        $seo_nofollow_category = $seo_general_settings['seo_nofollow_category'];
    } else {
        $seo_nofollow_category = '';
    }
    if (isset($seo_general_settings['seo_nofollow_archive'])) {
        $seo_nofollow_archive = $seo_general_settings['seo_nofollow_archive'];
    } else {
        $seo_nofollow_archive = '';
    }
    if (isset($seo_general_settings['seo_nofollow_search'])) {
        $seo_nofollow_search = $seo_general_settings['seo_nofollow_search'];
    } else {
        $seo_nofollow_search = '';
    }
    if (isset($seo_general_settings['seo_nofollow_tax'])) {
        $seo_nofollow_tax = $seo_general_settings['seo_nofollow_tax'];
    } else {
        $seo_nofollow_tax = '';
    }
    if (isset($seo_general_settings['seo_nofollow_nf'])) {
        $seo_nofollow_nf = $seo_general_settings['seo_nofollow_nf'];
    } else {
        $seo_nofollow_nf = '';
    }
    if (isset($seo_general_settings['seo_nofollow_home'])) {
        $seo_nofollow_home = $seo_general_settings['seo_nofollow_home'];
    } else {
        $seo_nofollow_home = '';
    }
    if (isset($seo_general_settings['seo_nofollow_tag'])) {
        $seo_nofollow_tag = $seo_general_settings['seo_nofollow_tag'];
    } else {
        $seo_nofollow_tag = '';
    }
    
    if (isset($seo_general_settings['seo_noodp_category'])) {
        $seo_noodp_category = $seo_general_settings['seo_noodp_category'];
    } else {
        $seo_noodp_category = '';
    }
    if (isset($seo_general_settings['seo_noodp_archive'])) {
        $seo_noodp_archive = $seo_general_settings['seo_noodp_archive'];
    } else {
        $seo_noodp_archive = '';
    }
    if (isset($seo_general_settings['seo_noodp_search'])) {
        $seo_noodp_search = $seo_general_settings['seo_noodp_search'];
    } else {
        $seo_noodp_search = '';
    }
    if (isset($seo_general_settings['seo_noodp_tax'])) {
        $seo_noodp_tax = $seo_general_settings['seo_noodp_tax'];
    } else {
        $seo_noodp_tax = '';
    }
    if (isset($seo_general_settings['seo_noodp_nf'])) {
        $seo_noodp_nf = $seo_general_settings['seo_noodp_nf'];
    } else {
        $seo_noodp_nf = '';
    }
    if (isset($seo_general_settings['seo_noodp_home'])) {
        $seo_noodp_home = $seo_general_settings['seo_noodp_home'];
    } else {
        $seo_noodp_home = '';
    }
    if (isset($seo_general_settings['seo_noodp_tag'])) {
        $seo_noodp_tag = $seo_general_settings['seo_noodp_tag'];
    } else {
        $seo_noodp_tag = '';
    }
    
    if (isset($seo_general_settings['seo_noydir_category'])) {
        $seo_noydir_category = $seo_general_settings['seo_noydir_category'];
    } else {
        $seo_noydir_category = '';
    }
    if (isset($seo_general_settings['seo_noydir_archive'])) {
        $seo_noydir_archive = $seo_general_settings['seo_noydir_archive'];
    } else {
        $seo_noydir_archive = '';
    }
    if (isset($seo_general_settings['seo_noydir_search'])) {
        $seo_noydir_search = $seo_general_settings['seo_noydir_search'];
    } else {
        $seo_noydir_search = '';
    }
    if (isset($seo_general_settings['seo_noydir_tax'])) {
        $seo_noydir_tax = $seo_general_settings['seo_noydir_tax'];
    } else {
        $seo_noydir_tax = '';
    }
    if (isset($seo_general_settings['seo_noydir_nf'])) {
        $seo_noydir_nf = $seo_general_settings['seo_noydir_nf'];
    } else {
        $seo_noydir_nf = '';
    }
    if (isset($seo_general_settings['seo_noydir_home'])) {
        $seo_noydir_home = $seo_general_settings['seo_noydir_home'];
    } else {
        $seo_noydir_home = '';
    }
    if (isset($seo_general_settings['seo_noydir_tag'])) {
        $seo_noydir_tag = $seo_general_settings['seo_noydir_tag'];
    } else {
        $seo_noydir_tag = '';
    }
    if (isset($seo_general_settings['seo_nofollow_posts'])) {
        $seo_nofollow_posts = $seo_general_settings['seo_nofollow_posts'];
    } else {
        $seo_nofollow_posts = '';
    }
    if (isset($seo_general_settings['seo_nofollow_pages'])) {
        $seo_nofollow_pages = $seo_general_settings['seo_nofollow_pages'];
    } else {
        $seo_nofollow_pages = '';
    }
    if (isset($seo_general_settings['seo_nofollow_media'])) {
        $seo_nofollow_media = $seo_general_settings['seo_nofollow_media'];
    } else {
        $seo_nofollow_media = '';
    }
    if (isset($seo_general_settings['seo_noodp_posts'])) {
        $seo_noodp_posts = $seo_general_settings['seo_noodp_posts'];
    } else {
        $seo_noodp_posts = '';
    }
    if (isset($seo_general_settings['seo_noodp_pages'])) {
        $seo_noodp_pages = $seo_general_settings['seo_noodp_pages'];
    } else {
        $seo_noodp_pages = '';
    }
    if (isset($seo_general_settings['seo_noodp_media'])) {
        $seo_noodp_media = $seo_general_settings['seo_noodp_media'];
    } else {
        $seo_noodp_media = '';
    }
    if (isset($seo_general_settings['seo_noydir_posts'])) {
        $seo_noydir_posts = $seo_general_settings['seo_noydir_posts'];
    } else {
        $seo_noydir_posts = '';
    }
    if (isset($seo_general_settings['seo_noydir_pages'])) {
        $seo_noydir_pages = $seo_general_settings['seo_noydir_pages'];
    } else {
        $seo_noydir_pages = '';
    }
    if (isset($seo_general_settings['seo_noydir_media'])) {
        $seo_noydir_media = $seo_general_settings['seo_noydir_media'];
    } else {
        $seo_noydir_media = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter'])) {
        $seo_twitter = $seo_Twitter_Settings['seo_twitter'];
    } else {
        $seo_twitter = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_title'])) {
        $seo_twitter_title = $seo_Twitter_Settings['seo_twitter_title'];
    } else {
        $seo_twitter_title = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_description'])) {
        $seo_twitter_description = $seo_Twitter_Settings['seo_twitter_description'];
    } else {
        $seo_twitter_description = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_sw'])) {
        $seo_twitter_image_sw = $seo_Twitter_Settings['seo_twitter_image_sw'];
    } else {
        $seo_twitter_image_sw = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook'])) {
        $seo_facebook = $seo_Facebook_Settings['seo_facebook'];
    } else {
        $seo_facebook = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_locale'])) {
        $seo_facebook_locale = $seo_Facebook_Settings['seo_facebook_locale'];
    } else {
        $seo_facebook_locale = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_site_name'])) {
        $seo_facebook_show_site_name = $seo_Facebook_Settings['seo_facebook_show_site_name'];
    } else {
        $seo_facebook_show_site_name = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_title'])) {
        $seo_facebook_show_title = $seo_Facebook_Settings['seo_facebook_show_title'];
    } else {
        $seo_facebook_show_title = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_url'])) {
        $seo_facebook_show_url = $seo_Facebook_Settings['seo_facebook_show_url'];
    } else {
        $seo_facebook_show_url = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_type'])) {
        $seo_facebook_show_type = $seo_Facebook_Settings['seo_facebook_show_type'];
    } else {
        $seo_facebook_show_type = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_times'])) {
        $seo_facebook_show_times = $seo_Facebook_Settings['seo_facebook_show_times'];
    } else {
        $seo_facebook_show_times = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_sections'])) {
        $seo_facebook_show_sections = $seo_Facebook_Settings['seo_facebook_show_sections'];
    } else {
        $seo_facebook_show_sections = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_image'])) {
        $seo_facebook_show_image = $seo_Facebook_Settings['seo_facebook_show_image'];
    } else {
        $seo_facebook_show_image = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_description'])) {
        $seo_facebook_show_description = $seo_Facebook_Settings['seo_facebook_show_description'];
    } else {
        $seo_facebook_show_description = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_google_code'])) {
        $seo_google_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_google_code']));
    } else {
        $seo_google_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_validation_codes'])) {
        $seo_validation_codes = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_validation_codes']));
    } else {
        $seo_validation_codes = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_bing_code'])) {
        $seo_bing_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_bing_code']));
    } else {
        $seo_bing_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_yandex_code'])) {
        $seo_yandex_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_yandex_code']));
    } else {
        $seo_yandex_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_pinterest_code'])) {
        $seo_pinterest_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_pinterest_code']));
    } else {
        $seo_pinterest_code = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_user'])) {
        $twitter_user = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_user']));
    } else {
        $twitter_user = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_creator'])) {
        $seo_twitter_creator = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_creator']));
    } else {
        $v = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image'])) {
        $twitter_image = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image']));
    } else {
        $twitter_image = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_alt'])) {
        $seo_twitter_image_alt = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image_alt']));
    } else {
        $seo_twitter_image_alt = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_image'])) {
        $facebook_image = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_image']));
    } else {
        $facebook_image = '';
    }
    if (isset($seo_Common_Settings['seo_common'])) {
        $seo_common = $seo_Common_Settings['seo_common'];
    } else {
        $seo_common = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_app_id'])) {
        $seo_facebook_app_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_app_id']));
    } else {
        $seo_facebook_app_id = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_admin_id'])) {
        $seo_facebook_admin_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_admin_id']));
    } else {
        $seo_facebook_admin_id = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_author'])) {
        $seo_facebook_author = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_author']));
    } else {
        $seo_facebook_author = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_publisher'])) {
        $seo_facebook_publisher = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_publisher']));
    } else {
        $seo_facebook_publisher = '';
    }
    if (isset($seo_Google_Settings['seo_google_publisher'])) {
        $seo_google_publisher = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_publisher']));
    } else {
        $seo_google_publisher = '';
    }
    if (isset($seo_Google_Settings['seo_google_en'])) {
        $seo_google_en = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_en']));
    } else {
        $seo_google_en = '';
    }
    if (isset($seo_Google_Settings['seo_google_author'])) {
        $seo_google_author = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_author']));
    } else {
        $seo_google_author = '';
    }
    if (isset($seo_Social_Links_Settings['seo_facebook_profile'])) {
        $seo_facebook_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_facebook_profile']));
    } else {
        $seo_facebook_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_social_links'])) {
        $seo_social_links = $seo_Social_Links_Settings['seo_social_links'];
    } else {
        $seo_social_links = '';
    }
    if (isset($seo_Social_Links_Settings['seo_twitter_profile'])) {
        $seo_twitter_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_twitter_profile']));
    } else {
        $seo_twitter_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_gplus_profile'])) {
        $seo_gplus_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_gplus_profile']));
    } else {
        $seo_gplus_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_instagram_profile'])) {
        $seo_instagram_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_instagram_profile']));
    } else {
        $seo_instagram_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_tumblr_profile'])) {
        $seo_tumblr_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_tumblr_profile']));
    } else {
        $seo_tumblr_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_pinterest_profile'])) {
        $seo_pinterest_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_pinterest_profile']));
    } else {
        $seo_pinterest_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_linkedin_profile'])) {
        $seo_linkedin_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_linkedin_profile']));
    } else {
        $seo_linkedin_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_soundcloud_profile'])) {
        $seo_soundcloud_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_soundcloud_profile']));
    } else {
        $seo_soundcloud_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_youtube_profile'])) {
        $seo_youtube_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_youtube_profile']));
    } else {
        $seo_youtube_profile = '';
    }
    if (isset($seo_Common_Settings['seo_copyright'])) {
        $seo_copyright = esc_html(sanitize_text_field($seo_Common_Settings['seo_copyright']));
    } else {
        $seo_copyright = '';
    }
    if (isset($seo_Common_Settings['seo_language'])) {
        $seo_language = esc_html(sanitize_text_field($seo_Common_Settings['seo_language']));
    } else {
        $seo_language = '';
    }
    if (isset($seo_Common_Settings['seo_author'])) {
        $seo_author = esc_html(sanitize_text_field($seo_Common_Settings['seo_author']));
    } else {
        $seo_author = '';
    }
    if (isset($seo_Common_Settings['seo_abstract'])) {
        $seo_abstract = esc_html(sanitize_text_field($seo_Common_Settings['seo_abstract']));
    } else {
        $seo_abstract = '';
    }
    if (isset($seo_Common_Settings['seo_dublin'])) {
        $seo_dublin = $seo_Common_Settings['seo_dublin'];
    } else {
        $seo_dublin = '';
    }
    if (isset($seo_Common_Settings['seo_canonical'])) {
        $seo_canonical = $seo_Common_Settings['seo_canonical'];
    } else {
        $seo_canonical = '';
    }
    if (isset($seo_Common_Settings['seo_show_descript'])) {
        $seo_show_descript = $seo_Common_Settings['seo_show_descript'];
    } else {
        $seo_show_descript = '';
    }
    if (is_single()) {
        $post = get_post();
        if (trim($post->post_excerpt) != '') {
            $seo_blog_description = trim($post->post_excerpt);
        } else {
            $seo_blog_description = trim($post->post_content);
        }
        $seo_blog_description = mb_substr(esc_attr(strip_tags(strip_shortcodes(stripslashes($seo_blog_description)))), 0, 160);
    } else {
        $seo_blog_description = get_bloginfo('description');
    }
    if (is_single()) {
        $seo_facebook_type = 'Article';
    } else {
        if (isset($seo_Facebook_Settings['seo_facebook_type'])) {
            $seo_facebook_type = $seo_Facebook_Settings['seo_facebook_type'];
        } else {
            $seo_facebook_type = 'Website';
        }
    }
    if (isset($seo_Twitter_Settings['seo_twitter_type'])) {
        $seo_twitter_type = $seo_Twitter_Settings['seo_twitter_type'];
    } else {
        $seo_twitter_type = 'summary';
    }
    if ($activatedRadioValue == 'seo_YES') {
        echo "\r\n<!-- FWD SEO TOOLS START -->\r\n\r\n";
        if ($seo_social_links == 'on') {
            seo_add_ldjsons($seo_facebook_profile, $seo_twitter_profile, $seo_gplus_profile, $seo_youtube_profile, $seo_pinterest_profile, $seo_tumblr_profile, $seo_soundcloud_profile, $seo_instagram_profile, $seo_linkedin_profile);
        }
        if (seo_get_page_type() == "single") {
            $robots = "";
            if ($seo_noindex_posts == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_posts == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_posts == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_posts == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_posts == "on") || ($seo_noodp_posts == "on") || ($seo_nofollow_posts == "on") || ($seo_noindex_posts == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "page") {
            $robots = "";
            if ($seo_noindex_pages == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_pages == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_pages == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_pages == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_pages == "on") || ($seo_noodp_pages == "on") || ($seo_nofollow_pages == "on") || ($seo_noindex_pages == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "attachment") {
            $robots = "";
            if ($seo_noindex_media == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_media == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_media == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_media == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_media == "on") || ($seo_noodp_media == "on") || ($seo_nofollow_media == "on") || ($seo_noindex_media == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "category") {
            $robots = "";
            if ($seo_noindex_category == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_category == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_category == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_category == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_category == "on") || ($seo_noodp_category == "on") || ($seo_nofollow_category == "on") || ($seo_noindex_category == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "archive") {
            $robots = "";
            if ($seo_noindex_archive == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_archive == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_archive == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_archive == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_archive == "on") || ($seo_noodp_archive == "on") || ($seo_nofollow_archive == "on") || ($seo_noindex_archive == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "search") {
            $robots = "";
            if ($seo_noindex_search == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_search == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_search == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_search == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_search == "on") || ($seo_noodp_search == "on") || ($seo_nofollow_search == "on") || ($seo_noindex_search == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "tax") {
            $robots = "";
            if ($seo_noindex_tax == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tax == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tax == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tax == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tax == "on") || ($seo_noodp_tax == "on") || ($seo_nofollow_tax == "on") || ($seo_noindex_tax == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "notfound") {
            $robots = "";
            if ($seo_noindex_nf == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_nf == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_nf == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_nf == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_nf == "on") || ($seo_noodp_nf == "on") || ($seo_nofollow_nf == "on") || ($seo_noindex_nf == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if ((seo_get_page_type() == "tag") || (seo_get_page_type() == "front")) {
            $robots = "";
            if ($seo_noindex_home == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_home == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_home == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_home == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_home == "on") || ($seo_noodp_home == "on") || ($seo_nofollow_home == "on") || ($seo_noindex_home == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "home") {
            $robots = "";
            if ($seo_noindex_tag == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tag == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tag == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tag == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tag == "on") || ($seo_noodp_tag == "on") || ($seo_nofollow_tag == "on") || ($seo_noindex_tag == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if ($seo_common == 'on') {
            if ($seo_copyright != "") {
?>
<meta content='<?php
                echo $seo_copyright;
?>' name='copyright'/>
<?php
            }
            if ($seo_language != "") {
?>
<meta content='<?php
                echo $seo_language;
?>' name='language'/>
<?php
            }
            if ($seo_author != "") {
?>
<meta content='<?php
                echo $seo_author;
?>' name='web_author'/>
<?php
            }
            if ($seo_abstract != "") {
?>
<meta content='<?php
                echo $seo_abstract;
?>' name='abstract'/>
<?php
            }
            if ($seo_dublin == 'on') {
                if ($seo_language != "") {
?>
<meta CONTENT='<?php
                    echo $seo_language;
?>' name='dc.language'/>
<?php
                }
?>
<meta CONTENT='<?php
                the_title();
?>' name='dc.title'/>
<?php
                if ($seo_abstract != "") {
?>
<meta CONTENT='<?php
                    echo $seo_abstract;
?>' name='dc.subject'/>
<?php
                }
?>
<meta expr:content<?php
                echo $seo_blog_description;
?>' name='dc.description'/> 
<?php
            }
            if ($seo_canonical == 'on') {
?>
<meta href='<?php
                echo the_permalink();
?>' name='canonical'/>
<?php
            }
        }
        if ($seo_google_en == 'on') {
            if ($seo_google_publisher != "") {
?>
<link href='<?php
                echo $seo_google_publisher;
?>' rel='publisher'/>
<?php
            }
            if ($seo_google_author != "") {
?>
<link href='<?php
                echo $seo_google_author;
?>' rel='author'/>
<?php
            }
        }
        if ($seo_show_descript == 'on') {
?>
<meta name="description" content="<?php
            echo $seo_blog_description;
?>"/>
<?php
        }
        if ($seo_validation_codes == 'on') {
            if ($seo_pinterest_code != "") {
?>
<meta name="p:domain_verify" content="<?php
                echo $seo_pinterest_code;
?>"/>
<?php
            }
            if ($seo_google_code != "") {
?>
<meta name="google-site-verification" content="<?php
                echo $seo_google_code;
?>" />
<?php
            }
            if ($seo_bing_code != "") {
?>
<meta name="msvalidate.01" content="<?php
                echo $seo_bing_code;
?>" />
<?php
            }
            if ($seo_yandex_code != "") {
?>
<meta content='<?php
                echo $seo_yandex_code;
?>' name='yandex-verification'/>
<?php
            }
        }
        if ($seo_facebook == 'on') {
            if ($seo_facebook_app_id != "") {
?>
    <meta content='<?php
                echo $seo_facebook_app_id;
?>' property='fb:app_id'/>
    <?php
            }
            if ($seo_facebook_admin_id != "") {
?>
    <meta content='<?php
                echo $seo_facebook_admin_id;
?>' property='fb:admins'/>
    <?php
            }
            if ($seo_facebook_show_title == 'on') {
?>
    <meta property="og:title" content="<?php
                echo the_title();
?>" />
    <?php
            }
            if ($seo_facebook_show_site_name == 'on') {
?>
    <meta property="og:site_name" content="<?php
                bloginfo('name');
?>" />
    <?php
            }
            if ($seo_facebook_show_url == 'on') {
?>
    <meta property="og:url" content="<?php
                the_permalink();
?>" />
    <?php
            }
            if ($seo_facebook_show_description == 'on') {
?>
    <meta property="og:description" content="<?php
                echo $seo_blog_description;
?>" />
    <?php
            }
            if ($seo_facebook_locale == 'on') {
?>
    <meta property="og:locale" content="<?php
                echo fetch_locale('');
?>" />
    <?php
            }
            if ($seo_facebook_show_type == 'on') {
?>
    <meta property="og:type" content="<?php
                echo $seo_facebook_type;
?>" />
    <?php
            }
?>
    <meta property="og:updated_time" content="<?php
            the_modified_date();
?>" />
    <?php
            if ($seo_facebook_show_image == 'on') {
                if (is_single()) {
                    if ($facebook_image == "") {
                        $facebook_image = "http://www.artwithimpact.org/sites/default/files/images/icon_facebook_0.png";
                    }
                    $image = get_open_graph_post_image($facebook_image);
?>
<meta property="og:image" content="<?php
                    echo $image;
?>"/>  
<?php
                } else {
                    if ($facebook_image == "") {
                        $facebook_image = "http://www.artwithimpact.org/sites/default/files/images/icon_facebook_0.png";
                    }
?>
    <meta property="og:image" content="<?php
                    echo $facebook_image;
?>"/>
    <?php
                }
            }
            //rew!
            if (is_single()) {
                if ($seo_facebook_publisher != "") {
?>
        <meta property="article:publisher" content="<?php
                    echo $seo_facebook_publisher;
?>" />
        <?php
                }
                if ($seo_facebook_author != "") {
?>
        <meta property="article:author" content="<?php
                    echo $seo_facebook_author;
?>" />
        <?php
                }
                if ($seo_facebook_show_times == 'on') {
?>
    <meta property="article:published_time" content="<?php
                    echo get_the_date();
?>" />
    <meta property="article:modified_time" content="<?php
                    echo the_modified_date();
?>" />
    <meta property="article:updated_time" content="<?php
                    echo the_modified_date();
?>" />
    <?php
                }
                if ($seo_facebook_show_sections == 'on') {
                    $cats = get_the_category();
                    if (!is_wp_error($cats) && (is_array($cats) && count($cats) > 0)) {
                        foreach ($cats as $cat) {
                            echo '<meta property="article:section" content="' . trim(esc_attr($cat->name)) . '"/>' . NL;
                        }
                    }
                }
            }
        }
        if ($seo_twitter == 'on') {
?>
<meta name="twitter:card" content="<?php
            echo $seo_twitter_type;
?>" />
<?php
            if ($seo_twitter_description == 'on') {
?>
<meta name="twitter:description" content="<?php
                echo $seo_blog_description;
?>" />
<?php
            }
            if ($seo_twitter_title == 'on') {
?>
<meta name="twitter:title" content="<?php
                the_title();
?>" />
<?php
            }
            if ($twitter_user != "") {
?>
<meta name="twitter:site" content="<?php
                echo prepend_at_symbol($twitter_user);
?>" />
<?php
            }
            if ($seo_twitter_creator != "") {
?>
<meta name="twitter:creator" content="<?php
                echo prepend_at_symbol($seo_twitter_creator);
?>" />
<?php
            }
            if ($seo_twitter_image_sw == 'on') {
                if (is_single()) {
                    if (has_post_thumbnail()) {
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
?> 
<meta name="twitter:image" content="<?php
                        echo $image[0];
?>"/>
<?php
                        if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                            echo $seo_twitter_image_alt;
?>"/>
<?php
                        }
                    } else {
                        if ($twitter_image != '') {
?>
<meta name="twitter:image" content="<?php
                            echo $twitter_image;
?>"/>
<?php
                        }
                        if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                            echo $seo_twitter_image_alt;
?>"/><?php
                        }
                    }
                } else {
                    if ($twitter_image != '') {
?>
<meta name="twitter:image" content="<?php
                        echo $twitter_image;
?>"/>
<?php
                    }
                    if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                        echo $seo_twitter_image_alt;
?>"/><?php
                    }
                }
            }
        }
        echo "\r\n\r\n<!-- FWD SEO TOOLS END -->\r\n\r\n";
    }
}
?>
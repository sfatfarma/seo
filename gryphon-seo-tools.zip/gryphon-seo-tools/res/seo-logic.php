<?php
function seo_fetch_locale($match = '')
{
    if (empty($match))
        $match = get_locale();
    $match_len     = strlen($match);
    $valid_locales = (array) seo_fb_locales();
    $default       = 'en_US';
    if ($match_len > 5) {
        $match     = substr($match, 0, 5);
        $match_len = 5;
    }
    if (5 === $match_len) {
        if (in_array($match, $valid_locales))
            return $match;
        $match     = substr($match, 0, 2);
        $match_len = 2;
    }
    if (2 === $match_len) {
        $locale_keys = (array) seo_language_keys();
        if ($key = array_search($match, $locale_keys)) {
            return $valid_locales[$key];
        }
    }
    return $default;
}

function seo_fb_open_graph_add_opengraph_namespace($output)
{
    if (stristr($output, 'xmlns:og')) {
    } else {
        $output = $output . ' xmlns:og="http://ogp.me/ns#"';
    }
    if (stristr($output, 'xmlns:fb')) {
    } else {
        $output = $output . ' xmlns:fb="http://ogp.me/ns/fb#"';
    }
    return $output;
}
add_filter('language_attributes', 'seo_fb_open_graph_add_opengraph_namespace', 9999);
add_action('wp_head', 'fwd_seo_main');
function gryphon_prepend_at_symbol($twitter_profile)
{
    if ('@' !== $twitter_profile[0]) {
        $twitter_profile = '@' . $twitter_profile;
    }
    return $twitter_profile;
}

function seo_get_open_graph_post_image($default_image = '')
{
    $post      = get_post();
    $thumbdone = false;
    $fb_image  = '';
    if (is_attachment()) {
        if ($temp = wp_get_attachment_image_src(null, 'full')) {
            $fb_image = trim($temp[0]);
            if (trim($fb_image) != '') {
                $thumbdone = true;
            }
        }
    }
    if (!$thumbdone) {
        if (function_exists('get_post_thumbnail_id')) {
            if ($id_attachment = get_post_thumbnail_id($post->ID)) {
                $fb_image  = wp_get_attachment_url($id_attachment, false);
                $thumbdone = true;
            }
        }
    }
    if (!$thumbdone) {
        $imgreg = '/<img .*src=["\']([^ ^"^\']*)["\']/';
        preg_match_all($imgreg, trim($post->post_content), $matches);
        if ($matches[1]) {
            $imagetemp = false;
            foreach ($matches[1] as $image) {
                $pos = strpos($image, site_url());
                if ($pos === false) {
                    if (stristr($image, 'http://') || stristr($image, 'https://') || mb_substr($image, 0, 2) == '//') {
                        if (mb_substr($image, 0, 2) == '//')
                            $image = ((gryphon_isSecure()) ? 'https:' : 'http:') . $image;
                        $imagetemp = $image;
                    } else {
                        $imagetemp = site_url() . $image;
                    }
                } else {
                    $imagetemp = $image;
                }
                if ($imagetemp) {
                    $fb_image  = $imagetemp;
                    $thumbdone = true;
                    break;
                }
            }
        }
    }
    if (!$thumbdone) {
        $images = get_posts(array(
            'post_type' => 'attachment',
            'numberposts' => -1,
            'post_status' => null,
            'order' => 'ASC',
            'orderby' => 'menu_order',
            'post_mime_type' => 'image',
            'post_parent' => $post->ID
        ));
        if ($images) {
            foreach ($images as $image) {
                $imagetemp = wp_get_attachment_url($image->ID, false);
                $fb_image  = $imagetemp;
                $thumbdone = true;
                break;
            }
        }
    }
    if (!$thumbdone) {
        $fb_image = $default_image;
    }
    return $fb_image;
}

function seo_get_page_type()
{
    global $wp_query;
    $loop = 'notfound';
    if ($wp_query->is_page) {
        $loop = is_front_page() ? 'front' : 'page';
    } elseif ($wp_query->is_home) {
        $loop = 'home';
    } elseif ($wp_query->is_single) {
        $loop = ($wp_query->is_attachment) ? 'attachment' : 'single';
    } elseif ($wp_query->is_category) {
        $loop = 'category';
    } elseif ($wp_query->is_tag) {
        $loop = 'tag';
    } elseif ($wp_query->is_tax) {
        $loop = 'tax';
    } elseif ($wp_query->is_archive) {
        if ($wp_query->is_day) {
            $loop = 'archive';
        } elseif ($wp_query->is_month) {
            $loop = 'archive';
        } elseif ($wp_query->is_year) {
            $loop = 'archive';
        } elseif ($wp_query->is_author) {
            $loop = 'archive';
        } else {
            $loop = 'archive';
        }
    } elseif ($wp_query->is_search) {
        $loop = 'search';
    } elseif ($wp_query->is_404) {
        $loop = 'notfound';
    }
    return $loop;
}
function seo_add_ldjsons()
{
    $type = json_encode('organization');
    $name = json_encode('name');
    $url  = json_encode(esc_url(home_url('/')));
    
    $logo = '';
    $icon = get_site_icon_url();
    if ($icon) {
        $logourl = esc_url_raw($icon);
        $logo    = json_encode($logourl) . ',';
    }
    
    $comma    = ',';
    $sameurls = '';
    $args     = func_get_args();
    foreach ($args as $index => $arg) {
        if ($arg != "") {
            $sameurls .= json_encode($arg) . $comma;
        }
        unset($args[$index]);
    }
    $sameurls = rtrim($sameurls, $comma);
    
    $output = '<script type="application/ld+json">{"@context:"http:\/\/schema.org","@type":"' . $type . '","name":"' . $name . '","url":"' . $url . '","logo":"' . $logo . '","sameAs":[' . $sameurls . ']}</script>' . "\r\n";
    echo $output;
    $output2 = '<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","name":"' . $name . '","url":"' . $url . '"}</script>';
    echo $output2;
    $output3 = '<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","url":"' . $url . '","name":"' . $name . '","potentialAction":{"@type":"SearchAction","target":"' . $url . '?s={search_term_string}","query-input":"required name=search_term_string"}}</script>';
    echo $output3;
}

function gryphon_seo_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}

function gryphon_isSecure() {
  return
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || $_SERVER['SERVER_PORT'] == 443;
}

function gryphon_search($search, $type) {
    $search_words = trim(preg_replace( "@[_-]@", " ", $search));
	$posts = get_posts( array( "s" => $search_words, "post_type" => $type ) );
	if ( count( $posts ) > 1 ) {
	    $titlematches = array();
	    foreach ( $posts as $post ) {
	        if ( strpos(strtolower($post->post_title), strtolower($search_words)) !== false ) {
	            $titlematches[] = $post;
	        }
	    }
	    if ( count($titlematches) == 1 ) {
	        return $titlematches;
	    }
	}
	
	return $posts;
}
function gryphon_get_redirect_url($url){
    $redirect_url = null; 

    $url_parts = @parse_url($url);
    if (!$url_parts) return false;
    if (!isset($url_parts['host'])) return false;
    if (!isset($url_parts['path'])) $url_parts['path'] = '/';

    $sock = fsockopen($url_parts['host'], (isset($url_parts['port']) ? (int)$url_parts['port'] : 80), $errno, $errstr, 30);
    if (!$sock) return false;

    $request = "HEAD " . $url_parts['path'] . (isset($url_parts['query']) ? '?'.$url_parts['query'] : '') . " HTTP/1.1".PHP_EOL; 
    $request .= 'Host: ' . $url_parts['host'] . PHP_EOL; 
    $request .= "Connection: Close".PHP_EOL.PHP_EOL; 
    fwrite($sock, $request);
    $response = '';
    while(!feof($sock)) $response .= fread($sock, 8192);
    fclose($sock);

    if (preg_match('/^Location: (.+?)$/m', $response, $matches)){
        if ( substr($matches[1], 0, 1) == "/" )
            return $url_parts['scheme'] . "://" . $url_parts['host'] . trim($matches[1]);
        else
            return trim($matches[1]);

    } else {
        return false;
    }
}
function gryphon_get_all_redirects($url){
    $redirects = array();
    while ($newurl = gryphon_get_redirect_url($url)){
        if (in_array($newurl, $redirects)){
            break;
        }
        $redirects[] = $newurl;
        $url = $newurl;
    }
    return $redirects;
}
function gryphon_get_final_url($url){
    if (strpos($url, 'localhost') !== false)
    {
        return $url;
    }
    $redirects = gryphon_get_all_redirects($url);
    if (count($redirects)>0){
        return array_pop($redirects);
    } else {
        return $url;
    }
}
function gryphon_wp_redirect($url, $type)
{
    if(!headers_sent())
    {
        wp_redirect($url, $type);
    }
    else
    {
        echo '<meta http-equiv="refresh" content="0;url='.$url.'"/>';
    }
    exit();
}
remove_filter('template_redirect', 'redirect_canonical');
add_action('template_redirect', 'seo_redirect_function');
//redirect part since v1.2
function seo_redirect_function()
{
    $seo_general_settings          = get_option('seo_General_Settings', false);
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
    $seo_Redirect_Settings         = get_option('seo_Redirect_Settings', false);
    if ($activatedRadioValue == 'seo_YES') {
        if(isset($seo_Redirect_Settings['redirect_enable']) && $seo_Redirect_Settings['redirect_enable'] === 'on')
        {
            if ( is_404() )
            {
                $get_params = "";
                if ( preg_match("@/?(\?.*)@", $_SERVER["REQUEST_URI"], $matches) ) {
                    $get_params = $matches[1];
                }
                
                $patterns_array = array();
                $patterns_array[] = "/(trackback|feed|(comment-)?page-?[0-9]*)/?$";
                $patterns_array[] = "\.(html|php)$";
                $patterns_array[] = "/?\?.*";
                $patterns_array = array_map(create_function('$a', '$sep = (strpos($a, "@") === false ? "@" : "%"); return $sep.trim($a).$sep."i";'), $patterns_array);
                
                $search = preg_replace( $patterns_array, "", urldecode( $_SERVER["REQUEST_URI"] ) );
                $search = basename(trim($search));
                $search = str_replace("_", "-", $search);
                $search = trim(preg_replace( $patterns_array, "", $search));
                
                if ( !$search ) return;
                
                $search_words = trim(preg_replace( "@[_-]@", " ", $search));
                $GLOBALS["__gryphon"]["search_words"] = explode(" ", $search_words);
                $GLOBALS["__gryphon"]["suggestions"] = array();

                $search_groups = array("posts","pages","tags","categories");
                
                foreach ( $search_groups as $group ) {
                    switch ( $group ) {
                        case "posts":
                            $posts = get_posts( array( "name" => $search, "post_type" => "post" ) );
                            if ( count( $posts ) == 1 ) {
                                gryphon_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                            }
                            break;
                            
                        case "pages":
                            $posts = get_posts( array( "name" => $search, "post_type" => "page" ) );
                            if ( count( $posts ) == 1 ) {
                                gryphon_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                            }
                            break;
                            
                        case "tags":
                            $tags = get_tags( array ( "name__like" => $search ) );
                            if ( count($tags) == 1) {
                                gryphon_wp_redirect(get_tag_link($tags[0]->term_id) . $get_params, 301);
                            }
                            break;
                            
                        case "categories":
                            $categories = get_categories( array ( "name__like" => $search ) );
                            if ( count($categories) == 1) {
                                gryphon_wp_redirect(get_category_link($categories[0]->term_id) . $get_params, 301);
                            }
                            break;
                    }
                }
                
                foreach ( $search_groups as $group ) {
                    switch ( $group ) {
                        case "posts":
                            $posts = gryphon_search($search, "post");
                            if ( count( $posts ) == 1 ) {
                                gryphon_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                            }

                            $GLOBALS["__gryphon"]["suggestions"] = array_merge ( (array)$GLOBALS["__gryphon"]["suggestions"], $posts );
                            break;
                            
                        case "pages":
                            $posts = gryphon_search($search, "page");
                            if ( count( $posts ) == 1 ) {
                                gryphon_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                            }

                            $GLOBALS["__gryphon"]["suggestions"] = array_merge ( (array)$GLOBALS["__gryphon"]["suggestions"], $posts );
                            break;
                    }
                }
            }  
        }
        if(isset($seo_Redirect_Settings['redirect_404_enable']) && $seo_Redirect_Settings['redirect_404_enable'] === 'on')
        {
            if ( is_404() )
            {
                $redirect_404_link = $seo_Redirect_Settings['redirect_404_link'];
                if(isset($redirect_404_link) && $redirect_404_link !== '')
                {
                    gryphon_wp_redirect($redirect_404_link, 301);
                }
            }
        }
        if(isset($seo_Redirect_Settings['redirect_http']) && $seo_Redirect_Settings['redirect_http'] !== 'No')
        {
            if ($seo_Redirect_Settings['redirect_http'] === 'Http') 
            {
                if(gryphon_isSecure())
                {
                    if ( 0 === strpos( $_SERVER['REQUEST_URI'], 'https' ) ) 
                    {
                        gryphon_wp_redirect( preg_replace( '|^https://|', 'http://', $_SERVER['REQUEST_URI'] ), 301 );
                    }
                    elseif(0 !== strpos( $_SERVER['REQUEST_URI'], 'http' ))
                    {
                        gryphon_wp_redirect( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
                    }
                }
            }
            elseif($seo_Redirect_Settings['redirect_http'] === 'Https')
            {
                if(!gryphon_isSecure())
                {
                    if ( 0 === strpos( $_SERVER['REQUEST_URI'], 'http' ) && 0 !== strpos( $_SERVER['REQUEST_URI'], 'https' )) 
                    {
                        gryphon_wp_redirect( preg_replace( '|^http://|', 'https://', $_SERVER['REQUEST_URI'] ), 301 );     
                    }
                    elseif(0 !== strpos( $_SERVER['REQUEST_URI'], 'https' ) )
                    {
                        gryphon_wp_redirect( 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
                    }
                }
            }
        }
        if(isset($seo_Redirect_Settings['redirect_www']) && $seo_Redirect_Settings['redirect_www'] !== 'No')
        {
            if ($seo_Redirect_Settings['redirect_www'] === 'www') 
            {
                if(isset($_SERVER['HTTP_HOST']) && substr($_SERVER['HTTP_HOST'], 0, 4) !== 'www.')
                {
                    $pageURL = (gryphon_isSecure()) ? "https://" : "http://";
                    if ($_SERVER["SERVER_PORT"] != "80")
                    {
                        $pageURL .= "www." . $_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
                    } 
                    else 
                    {
                        $pageURL .= "www." . $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
                    }
                    gryphon_wp_redirect( $pageURL, 301 );
                }
            }
            elseif($seo_Redirect_Settings['redirect_www'] === 'no-www')
            {
                if(isset($_SERVER['HTTP_HOST']) && substr($_SERVER['HTTP_HOST'], 0, 4) === 'www.')
                {
                    $pageURL = (gryphon_isSecure()) ? "https://" : "http://";
                    if ($_SERVER["SERVER_PORT"] != "80")
                    {
                        $pageURL .= substr($_SERVER['HTTP_HOST'], 4).":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
                    } 
                    else 
                    {
                        $pageURL .= substr($_SERVER['HTTP_HOST'], 4).$_SERVER["REQUEST_URI"];
                    }
                    gryphon_wp_redirect( $pageURL, 301 );
                }
            }
        }
        if(isset($seo_Redirect_Settings['redirect_attachment']) && $seo_Redirect_Settings['redirect_attachment'] === 'on')
        {
            if ( is_attachment() && isset($post->post_parent) && is_numeric($post->post_parent) && ($post->post_parent != 0) ) {
                gryphon_wp_redirect(get_permalink($post->post_parent), 301);
            } elseif ( is_attachment() && isset($post->post_parent) && is_numeric($post->post_parent) && ($post->post_parent < 1) ) {
                gryphon_wp_redirect(get_bloginfo('wpurl'), 302);       
            }
        }
        $bot = false;
        if(isset($_SERVER['HTTP_USER_AGENT']))
        {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            preg_match( '/ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
            preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|sogou|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
            if($goodbot || $badbot)
            {
                $bot = true;
            }
        }
        if(isset($seo_Redirect_Settings['redirect_badbot']) && $seo_Redirect_Settings['redirect_badbot'] === 'on')
        {
            if($badbot)
            {
                gryphon_wp_redirect("http://www.google.com", 301);
            }
        }
        $actual_link = 'http' . ((gryphon_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $short_url = str_ireplace(get_home_url(),'',$actual_link);
        $redirects = get_option('gryphon_301_redirects');
        if (!empty($redirects)) 
        {
            $cont = 0;
            foreach ($redirects as $storedrequest => $bundle[]) 
            {
                $bundle_values = array_values($bundle); 
                $myValues = $bundle_values[$cont];
                $cont = $cont + 1;
                $array_my_values = array_values($myValues); 
                $destination = $array_my_values[0];
                $device = $array_my_values[1];
                $active = $array_my_values[2];
                $wildcard = $array_my_values[3];
                if($active === '1')
                {
                    if($device != 'All')
                    {
                        if($device === 'Bot')
                        {
                            if($bot === false)
                            {
                                continue;
                            }
                        }
                        elseif($device === 'No-Bot')
                        {
                            if($bot === true)
                            {
                                continue;
                            }
                        }
                        elseif($device === 'Good-Bot')
                        {
                            if($goodbot != true)
                            {
                                continue;
                            }
                        }
                        elseif($device === 'Bad-Bot')
                        {
                            if($badbot != true)
                            {
                                continue;
                            }
                        }
                    }
                    $do_redirect = '';
                    $userrequest = gryphon_get_final_url($destination);
                    
                    if($actual_link !== $userrequest)
                    {
                        if ($wildcard === '1') {
                            if ( strpos($storedrequest, '/wp-login') !== 0 && strpos($storedrequest, '/wp-admin') !== 0 ) 
                            {
                                if (fnmatch($storedrequest, $short_url)) {
                                    $do_redirect = $userrequest;
                                }
                            }
                        }
                        else
                        {
                            if($short_url === rtrim($storedrequest,'/'))
                            {
                                $do_redirect = $destination;
                            }
                        }
                        if($do_redirect !== '')
                        {
                            if (trim($actual_link,'/') !== trim($userrequest,'/')) 
                            {
                                if (strpos($do_redirect,'/') === 0)
                                {
                                    $do_redirect = home_url().$do_redirect;
                                }
                                if (!headers_sent()) {
                                    header("HTTP/1.1 301 Moved Permanently");
                                    header("Status: 301 Moved Permanently");
                                    header("Location: " . $do_redirect);
                                    header("Connection: close");
                                    exit(0);
                                }
                                else
                                {
                                    gryphon_wp_redirect($do_redirect, 301);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

function gryphon_auto_add_alt_tags($content)
{
        global $post;
        $seo_Common_Settings = get_option('seo_Common_Settings', false);
        preg_match_all('/<img (.*?)\/>/', $content, $images);
        if(!is_null($images))
        {
            if (isset($seo_Common_Settings['seo_auto_add_image_alt']) && $seo_Common_Settings['seo_auto_add_image_alt'] == 'on')
            {
                foreach($images[0] as $index => $value)
                {
                        if(!preg_match('/alt=/', $value))
                        {
                                $new_img = str_replace('<img', '<img alt="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                                $images[0][$index] = $new_img;
                        }
                        elseif(preg_match('/alt=""/', $value))
                        {
                                $new_img = str_replace('alt=""', 'alt="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                                $images[0][$index] = $new_img;
                        }
                        elseif(preg_match('/alt=\'\'/', $value))
                        {
                                $new_img = str_replace('alt=\'\'', 'alt="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                                $images[0][$index] = $new_img;
                        }
                }
            }
            if (isset($seo_Common_Settings['seo_auto_add_image_title']) && $seo_Common_Settings['seo_auto_add_image_title'] == 'on')
            {
                foreach($images[0] as $index => $value)
                {
                        if(!preg_match('/title=/', $value))
                        {
                                $new_img = str_replace('<img', '<img title="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                        }
                        elseif(preg_match('/title=""/', $value))
                        {
                                $new_img = str_replace('title=""', 'title="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                        }
                        elseif(preg_match('/title=\'\'/', $value))
                        {
                                $new_img = str_replace('title=\'\'', 'title="'.$post->post_title.'"', $images[0][$index]);
                                $content = str_replace($images[0][$index], $new_img, $content);
                        }
                }
            }
        }
        return $content;
}

function fwd_seo_main()
{
    $seo_blog_description          = '';
    $seo_general_settings          = get_option('seo_General_Settings', false);
    $seo_Social_Links_Settings     = get_option('seo_Social_Links_Settings', false);
    $seo_Validation_Codes_Settings = get_option('seo_Validation_Codes_Settings', false);
    $seo_Twitter_Settings          = get_option('seo_Twitter_Settings', false);
    $seo_Common_Settings           = get_option('seo_Common_Settings', false);
    $seo_Google_Settings           = get_option('seo_Google_Settings', false);
    $seo_Facebook_Settings         = get_option('seo_Facebook_Settings', false);
    $seo_Analytics                 = get_option('seo_Analytics', false);
    if (isset($seo_Analytics['seo_google_analytics_id'])) {
        $seo_google_analytics_id = esc_html(sanitize_text_field($seo_Analytics['seo_google_analytics_id']));
    } else {
        $seo_google_analytics_id = '';
    }
    if (isset($seo_Analytics['seo_google_en'])) {
        $seo_google_en = $seo_Analytics['seo_google_en'];
    } else {
        $seo_google_en = '';
    }
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
    if (isset($seo_general_settings['seo_noindex_posts'])) {
        $seo_noindex_posts = $seo_general_settings['seo_noindex_posts'];
    } else {
        $seo_noindex_posts = '';
    }
    if (isset($seo_general_settings['seo_noindex_pages'])) {
        $seo_noindex_pages = $seo_general_settings['seo_noindex_pages'];
    } else {
        $seo_noindex_pages = '';
    }
    if (isset($seo_general_settings['seo_noindex_media'])) {
        $seo_noindex_media = $seo_general_settings['seo_noindex_media'];
    } else {
        $seo_noindex_media = '';
    }
    if (isset($seo_general_settings['seo_noindex_category'])) {
        $seo_noindex_category = $seo_general_settings['seo_noindex_category'];
    } else {
        $seo_noindex_category = '';
    }
    if (isset($seo_general_settings['seo_noindex_archive'])) {
        $seo_noindex_archive = $seo_general_settings['seo_noindex_archive'];
    } else {
        $seo_noindex_archive = '';
    }
    if (isset($seo_general_settings['seo_noindex_search'])) {
        $seo_noindex_search = $seo_general_settings['seo_noindex_search'];
    } else {
        $seo_noindex_search = '';
    }
    if (isset($seo_general_settings['seo_noindex_tax'])) {
        $seo_noindex_tax = $seo_general_settings['seo_noindex_tax'];
    } else {
        $seo_noindex_tax = '';
    }
    if (isset($seo_general_settings['seo_noindex_nf'])) {
        $seo_noindex_nf = $seo_general_settings['seo_noindex_nf'];
    } else {
        $seo_noindex_nf = '';
    }
    if (isset($seo_general_settings['seo_noindex_home'])) {
        $seo_noindex_home = $seo_general_settings['seo_noindex_home'];
    } else {
        $seo_noindex_home = '';
    }
    if (isset($seo_general_settings['seo_noindex_tag'])) {
        $seo_noindex_tag = $seo_general_settings['seo_noindex_tag'];
    } else {
        $seo_noindex_tag = '';
    }
    if (isset($seo_general_settings['seo_nofollow_category'])) {
        $seo_nofollow_category = $seo_general_settings['seo_nofollow_category'];
    } else {
        $seo_nofollow_category = '';
    }
    if (isset($seo_general_settings['seo_nofollow_archive'])) {
        $seo_nofollow_archive = $seo_general_settings['seo_nofollow_archive'];
    } else {
        $seo_nofollow_archive = '';
    }
    if (isset($seo_general_settings['seo_nofollow_search'])) {
        $seo_nofollow_search = $seo_general_settings['seo_nofollow_search'];
    } else {
        $seo_nofollow_search = '';
    }
    if (isset($seo_general_settings['seo_nofollow_tax'])) {
        $seo_nofollow_tax = $seo_general_settings['seo_nofollow_tax'];
    } else {
        $seo_nofollow_tax = '';
    }
    if (isset($seo_general_settings['seo_nofollow_nf'])) {
        $seo_nofollow_nf = $seo_general_settings['seo_nofollow_nf'];
    } else {
        $seo_nofollow_nf = '';
    }
    if (isset($seo_general_settings['seo_nofollow_home'])) {
        $seo_nofollow_home = $seo_general_settings['seo_nofollow_home'];
    } else {
        $seo_nofollow_home = '';
    }
    if (isset($seo_general_settings['seo_nofollow_tag'])) {
        $seo_nofollow_tag = $seo_general_settings['seo_nofollow_tag'];
    } else {
        $seo_nofollow_tag = '';
    }
    
    if (isset($seo_general_settings['seo_noodp_category'])) {
        $seo_noodp_category = $seo_general_settings['seo_noodp_category'];
    } else {
        $seo_noodp_category = '';
    }
    if (isset($seo_general_settings['seo_noodp_archive'])) {
        $seo_noodp_archive = $seo_general_settings['seo_noodp_archive'];
    } else {
        $seo_noodp_archive = '';
    }
    if (isset($seo_general_settings['seo_noodp_search'])) {
        $seo_noodp_search = $seo_general_settings['seo_noodp_search'];
    } else {
        $seo_noodp_search = '';
    }
    if (isset($seo_general_settings['seo_noodp_tax'])) {
        $seo_noodp_tax = $seo_general_settings['seo_noodp_tax'];
    } else {
        $seo_noodp_tax = '';
    }
    if (isset($seo_general_settings['seo_noodp_nf'])) {
        $seo_noodp_nf = $seo_general_settings['seo_noodp_nf'];
    } else {
        $seo_noodp_nf = '';
    }
    if (isset($seo_general_settings['seo_noodp_home'])) {
        $seo_noodp_home = $seo_general_settings['seo_noodp_home'];
    } else {
        $seo_noodp_home = '';
    }
    if (isset($seo_general_settings['seo_noodp_tag'])) {
        $seo_noodp_tag = $seo_general_settings['seo_noodp_tag'];
    } else {
        $seo_noodp_tag = '';
    }
    
    if (isset($seo_general_settings['seo_noydir_category'])) {
        $seo_noydir_category = $seo_general_settings['seo_noydir_category'];
    } else {
        $seo_noydir_category = '';
    }
    if (isset($seo_general_settings['seo_noydir_archive'])) {
        $seo_noydir_archive = $seo_general_settings['seo_noydir_archive'];
    } else {
        $seo_noydir_archive = '';
    }
    if (isset($seo_general_settings['seo_noydir_search'])) {
        $seo_noydir_search = $seo_general_settings['seo_noydir_search'];
    } else {
        $seo_noydir_search = '';
    }
    if (isset($seo_general_settings['seo_noydir_tax'])) {
        $seo_noydir_tax = $seo_general_settings['seo_noydir_tax'];
    } else {
        $seo_noydir_tax = '';
    }
    if (isset($seo_general_settings['seo_noydir_nf'])) {
        $seo_noydir_nf = $seo_general_settings['seo_noydir_nf'];
    } else {
        $seo_noydir_nf = '';
    }
    if (isset($seo_general_settings['seo_noydir_home'])) {
        $seo_noydir_home = $seo_general_settings['seo_noydir_home'];
    } else {
        $seo_noydir_home = '';
    }
    if (isset($seo_general_settings['seo_noydir_tag'])) {
        $seo_noydir_tag = $seo_general_settings['seo_noydir_tag'];
    } else {
        $seo_noydir_tag = '';
    }
    if (isset($seo_general_settings['seo_nofollow_posts'])) {
        $seo_nofollow_posts = $seo_general_settings['seo_nofollow_posts'];
    } else {
        $seo_nofollow_posts = '';
    }
    if (isset($seo_general_settings['seo_nofollow_pages'])) {
        $seo_nofollow_pages = $seo_general_settings['seo_nofollow_pages'];
    } else {
        $seo_nofollow_pages = '';
    }
    if (isset($seo_general_settings['seo_nofollow_media'])) {
        $seo_nofollow_media = $seo_general_settings['seo_nofollow_media'];
    } else {
        $seo_nofollow_media = '';
    }
    if (isset($seo_general_settings['seo_noodp_posts'])) {
        $seo_noodp_posts = $seo_general_settings['seo_noodp_posts'];
    } else {
        $seo_noodp_posts = '';
    }
    if (isset($seo_general_settings['seo_noodp_pages'])) {
        $seo_noodp_pages = $seo_general_settings['seo_noodp_pages'];
    } else {
        $seo_noodp_pages = '';
    }
    if (isset($seo_general_settings['seo_noodp_media'])) {
        $seo_noodp_media = $seo_general_settings['seo_noodp_media'];
    } else {
        $seo_noodp_media = '';
    }
    if (isset($seo_general_settings['seo_noydir_posts'])) {
        $seo_noydir_posts = $seo_general_settings['seo_noydir_posts'];
    } else {
        $seo_noydir_posts = '';
    }
    if (isset($seo_general_settings['seo_noydir_pages'])) {
        $seo_noydir_pages = $seo_general_settings['seo_noydir_pages'];
    } else {
        $seo_noydir_pages = '';
    }
    if (isset($seo_general_settings['seo_noydir_media'])) {
        $seo_noydir_media = $seo_general_settings['seo_noydir_media'];
    } else {
        $seo_noydir_media = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter'])) {
        $seo_twitter = $seo_Twitter_Settings['seo_twitter'];
    } else {
        $seo_twitter = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_title'])) {
        $seo_twitter_title = $seo_Twitter_Settings['seo_twitter_title'];
    } else {
        $seo_twitter_title = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_description'])) {
        $seo_twitter_description = $seo_Twitter_Settings['seo_twitter_description'];
    } else {
        $seo_twitter_description = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_sw'])) {
        $seo_twitter_image_sw = $seo_Twitter_Settings['seo_twitter_image_sw'];
    } else {
        $seo_twitter_image_sw = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook'])) {
        $seo_facebook = $seo_Facebook_Settings['seo_facebook'];
    } else {
        $seo_facebook = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_locale'])) {
        $seo_facebook_locale = $seo_Facebook_Settings['seo_facebook_locale'];
    } else {
        $seo_facebook_locale = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_site_name'])) {
        $seo_facebook_show_site_name = $seo_Facebook_Settings['seo_facebook_show_site_name'];
    } else {
        $seo_facebook_show_site_name = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_title'])) {
        $seo_facebook_show_title = $seo_Facebook_Settings['seo_facebook_show_title'];
    } else {
        $seo_facebook_show_title = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_url'])) {
        $seo_facebook_show_url = $seo_Facebook_Settings['seo_facebook_show_url'];
    } else {
        $seo_facebook_show_url = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_type'])) {
        $seo_facebook_show_type = $seo_Facebook_Settings['seo_facebook_show_type'];
    } else {
        $seo_facebook_show_type = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_times'])) {
        $seo_facebook_show_times = $seo_Facebook_Settings['seo_facebook_show_times'];
    } else {
        $seo_facebook_show_times = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_sections'])) {
        $seo_facebook_show_sections = $seo_Facebook_Settings['seo_facebook_show_sections'];
    } else {
        $seo_facebook_show_sections = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_image'])) {
        $seo_facebook_show_image = $seo_Facebook_Settings['seo_facebook_show_image'];
    } else {
        $seo_facebook_show_image = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_show_description'])) {
        $seo_facebook_show_description = $seo_Facebook_Settings['seo_facebook_show_description'];
    } else {
        $seo_facebook_show_description = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_google_code'])) {
        $seo_google_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_google_code']));
    } else {
        $seo_google_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_validation_codes'])) {
        $seo_validation_codes = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_validation_codes']));
    } else {
        $seo_validation_codes = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_bing_code'])) {
        $seo_bing_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_bing_code']));
    } else {
        $seo_bing_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_yandex_code'])) {
        $seo_yandex_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_yandex_code']));
    } else {
        $seo_yandex_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_pinterest_code'])) {
        $seo_pinterest_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_pinterest_code']));
    } else {
        $seo_pinterest_code = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_user'])) {
        $twitter_user = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_user']));
    } else {
        $twitter_user = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_creator'])) {
        $seo_twitter_creator = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_creator']));
    } else {
        $v = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image'])) {
        $twitter_image = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image']));
    } else {
        $twitter_image = '';
    }
    if (isset($seo_Twitter_Settings['seo_twitter_image_alt'])) {
        $seo_twitter_image_alt = esc_html(sanitize_text_field($seo_Twitter_Settings['seo_twitter_image_alt']));
    } else {
        $seo_twitter_image_alt = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_image'])) {
        $facebook_image = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_image']));
    } else {
        $facebook_image = '';
    }
    if (isset($seo_Common_Settings['seo_common'])) {
        $seo_common = $seo_Common_Settings['seo_common'];
    } else {
        $seo_common = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_app_id'])) {
        $seo_facebook_app_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_app_id']));
    } else {
        $seo_facebook_app_id = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_admin_id'])) {
        $seo_facebook_admin_id = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_admin_id']));
    } else {
        $seo_facebook_admin_id = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_author'])) {
        $seo_facebook_author = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_author']));
    } else {
        $seo_facebook_author = '';
    }
    if (isset($seo_Facebook_Settings['seo_facebook_publisher'])) {
        $seo_facebook_publisher = esc_html(sanitize_text_field($seo_Facebook_Settings['seo_facebook_publisher']));
    } else {
        $seo_facebook_publisher = '';
    }
    if (isset($seo_Google_Settings['seo_google_publisher'])) {
        $seo_google_publisher = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_publisher']));
    } else {
        $seo_google_publisher = '';
    }
    if (isset($seo_Google_Settings['seo_google_en'])) {
        $seo_google_en = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_en']));
    } else {
        $seo_google_en = '';
    }
    if (isset($seo_Google_Settings['seo_google_author'])) {
        $seo_google_author = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_author']));
    } else {
        $seo_google_author = '';
    }
    if (isset($seo_Social_Links_Settings['seo_facebook_profile'])) {
        $seo_facebook_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_facebook_profile']));
    } else {
        $seo_facebook_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_social_links'])) {
        $seo_social_links = $seo_Social_Links_Settings['seo_social_links'];
    } else {
        $seo_social_links = '';
    }
    if (isset($seo_Social_Links_Settings['seo_twitter_profile'])) {
        $seo_twitter_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_twitter_profile']));
    } else {
        $seo_twitter_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_gplus_profile'])) {
        $seo_gplus_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_gplus_profile']));
    } else {
        $seo_gplus_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_instagram_profile'])) {
        $seo_instagram_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_instagram_profile']));
    } else {
        $seo_instagram_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_tumblr_profile'])) {
        $seo_tumblr_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_tumblr_profile']));
    } else {
        $seo_tumblr_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_pinterest_profile'])) {
        $seo_pinterest_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_pinterest_profile']));
    } else {
        $seo_pinterest_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_linkedin_profile'])) {
        $seo_linkedin_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_linkedin_profile']));
    } else {
        $seo_linkedin_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_soundcloud_profile'])) {
        $seo_soundcloud_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_soundcloud_profile']));
    } else {
        $seo_soundcloud_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_youtube_profile'])) {
        $seo_youtube_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_youtube_profile']));
    } else {
        $seo_youtube_profile = '';
    }
    if (isset($seo_Common_Settings['seo_copyright'])) {
        $seo_copyright = esc_html(sanitize_text_field($seo_Common_Settings['seo_copyright']));
    } else {
        $seo_copyright = '';
    }
    if (isset($seo_Common_Settings['seo_language'])) {
        $seo_language = esc_html(sanitize_text_field($seo_Common_Settings['seo_language']));
    } else {
        $seo_language = '';
    }
    if (isset($seo_Common_Settings['seo_author'])) {
        $seo_author = esc_html(sanitize_text_field($seo_Common_Settings['seo_author']));
    } else {
        $seo_author = '';
    }
    if (isset($seo_Common_Settings['seo_abstract'])) {
        $seo_abstract = esc_html(sanitize_text_field($seo_Common_Settings['seo_abstract']));
    } else {
        $seo_abstract = '';
    }
    if (isset($seo_Common_Settings['seo_dublin'])) {
        $seo_dublin = $seo_Common_Settings['seo_dublin'];
    } else {
        $seo_dublin = '';
    }
    if (isset($seo_Common_Settings['seo_canonical'])) {
        $seo_canonical = $seo_Common_Settings['seo_canonical'];
    } else {
        $seo_canonical = '';
    }
    if (isset($seo_Common_Settings['seo_show_descript'])) {
        $seo_show_descript = $seo_Common_Settings['seo_show_descript'];
    } else {
        $seo_show_descript = '';
    }
    if (is_single()) {
        if ((isset($seo_Common_Settings['seo_auto_add_image_alt']) && $seo_Common_Settings['seo_auto_add_image_alt'] == 'on') || (isset($seo_Common_Settings['seo_auto_add_image_title']) && $seo_Common_Settings['seo_auto_add_image_title'] == 'on')) 
        {
            add_filter('the_content', 'gryphon_auto_add_alt_tags', 99999);
        }
        $post = get_post();
        if (trim($post->post_excerpt) != '') {
            $seo_blog_description = trim($post->post_excerpt);
        } else {
            $seo_blog_description = trim($post->post_content);
        }
        $seo_blog_description = mb_substr(esc_attr(strip_tags(strip_shortcodes(stripslashes($seo_blog_description)))), 0, 160);
        $seo_facebook_type = 'Article';
    } else {
        $seo_blog_description = get_bloginfo('description');
        if (isset($seo_Facebook_Settings['seo_facebook_type'])) {
            $seo_facebook_type = $seo_Facebook_Settings['seo_facebook_type'];
        } else {
            $seo_facebook_type = 'Website';
        }
    }
    if (isset($seo_Twitter_Settings['seo_twitter_type'])) {
        $seo_twitter_type = $seo_Twitter_Settings['seo_twitter_type'];
    } else {
        $seo_twitter_type = 'summary';
    }
    if ($activatedRadioValue == 'seo_YES') {
        echo "\r\n<!-- GRYPHON SEO TOOLS START -->\r\n\r\n";
        if ($seo_social_links == 'on') {
            seo_add_ldjsons($seo_facebook_profile, $seo_twitter_profile, $seo_gplus_profile, $seo_youtube_profile, $seo_pinterest_profile, $seo_tumblr_profile, $seo_soundcloud_profile, $seo_instagram_profile, $seo_linkedin_profile);
        }
        if (seo_get_page_type() == "single") {
            $robots = "";
            if ($seo_noindex_posts == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_posts == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_posts == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_posts == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_posts == "on") || ($seo_noodp_posts == "on") || ($seo_nofollow_posts == "on") || ($seo_noindex_posts == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "page") {
            $robots = "";
            if ($seo_noindex_pages == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_pages == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_pages == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_pages == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_pages == "on") || ($seo_noodp_pages == "on") || ($seo_nofollow_pages == "on") || ($seo_noindex_pages == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "attachment") {
            $robots = "";
            if ($seo_noindex_media == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_media == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_media == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_media == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_media == "on") || ($seo_noodp_media == "on") || ($seo_nofollow_media == "on") || ($seo_noindex_media == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "category") {
            $robots = "";
            if ($seo_noindex_category == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_category == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_category == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_category == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_category == "on") || ($seo_noodp_category == "on") || ($seo_nofollow_category == "on") || ($seo_noindex_category == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "archive") {
            $robots = "";
            if ($seo_noindex_archive == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_archive == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_archive == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_archive == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_archive == "on") || ($seo_noodp_archive == "on") || ($seo_nofollow_archive == "on") || ($seo_noindex_archive == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "search") {
            $robots = "";
            if ($seo_noindex_search == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_search == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_search == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_search == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_search == "on") || ($seo_noodp_search == "on") || ($seo_nofollow_search == "on") || ($seo_noindex_search == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "tax") {
            $robots = "";
            if ($seo_noindex_tax == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tax == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tax == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tax == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tax == "on") || ($seo_noodp_tax == "on") || ($seo_nofollow_tax == "on") || ($seo_noindex_tax == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "notfound") {
            $robots = "";
            if ($seo_noindex_nf == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_nf == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_nf == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_nf == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_nf == "on") || ($seo_noodp_nf == "on") || ($seo_nofollow_nf == "on") || ($seo_noindex_nf == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if ((seo_get_page_type() == "tag") || (seo_get_page_type() == "front")) {
            $robots = "";
            if ($seo_noindex_home == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_home == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_home == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_home == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_home == "on") || ($seo_noodp_home == "on") || ($seo_nofollow_home == "on") || ($seo_noindex_home == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (seo_get_page_type() == "home") {
            $robots = "";
            if ($seo_noindex_tag == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tag == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tag == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tag == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tag == "on") || ($seo_noodp_tag == "on") || ($seo_nofollow_tag == "on") || ($seo_noindex_tag == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if ($seo_common == 'on') {
            if ($seo_copyright != "") {
?>
<meta content='<?php
                echo $seo_copyright;
?>' name='copyright'/>
<?php
            }
            if ($seo_language != "") {
?>
<meta content='<?php
                echo $seo_language;
?>' name='language'/>
<?php
            }
            if ($seo_author != "") {
?>
<meta content='<?php
                echo $seo_author;
?>' name='web_author'/>
<?php
            }
            if ($seo_abstract != "") {
?>
<meta content='<?php
                echo $seo_abstract;
?>' name='abstract'/>
<?php
            }
            if ($seo_dublin == 'on') {
                if ($seo_language != "") {
?>
<meta CONTENT='<?php
                    echo $seo_language;
?>' name='dc.language'/>
<?php
                }
?>
<meta CONTENT='<?php
                the_title();
?>' name='dc.title'/>
<?php
                if ($seo_abstract != "") {
?>
<meta CONTENT='<?php
                    echo $seo_abstract;
?>' name='dc.subject'/>
<?php
                }
?>
<meta content='<?php
                echo $seo_blog_description;
?>' name='dc.description'/> 
<?php
            }
            if ($seo_canonical == 'on') {
?>
<meta href='<?php
                echo the_permalink();
?>' name='canonical'/>
<?php
            }
        }
        if ($seo_google_en == 'on') {
            if ($seo_google_publisher != "") {
?>
<link href='<?php
                echo $seo_google_publisher;
?>' rel='publisher'/>
<?php
            }
            if ($seo_google_author != "") {
?>
<link href='<?php
                echo $seo_google_author;
?>' rel='author'/>
<?php
            }
        }
        if ($seo_show_descript == 'on') {
?>
<meta name="description" content="<?php
            echo $seo_blog_description;
?>"/>
<?php
        }
        if ($seo_validation_codes == 'on') {
            if ($seo_pinterest_code != "") {
?>
<meta name="p:domain_verify" content="<?php
                echo $seo_pinterest_code;
?>"/>
<?php
            }
            if ($seo_google_code != "") {
?>
<meta name="google-site-verification" content="<?php
                echo $seo_google_code;
?>" />
<?php
            }
            if ($seo_bing_code != "") {
?>
<meta name="msvalidate.01" content="<?php
                echo $seo_bing_code;
?>" />
<?php
            }
            if ($seo_yandex_code != "") {
?>
<meta content='<?php
                echo $seo_yandex_code;
?>' name='yandex-verification'/>
<?php
            }
        }
        if ($seo_facebook == 'on') {
            if ($seo_facebook_app_id != "") {
?>
    <meta content='<?php
                echo $seo_facebook_app_id;
?>' property='fb:app_id'/>
    <?php
            }
            if ($seo_facebook_admin_id != "") {
?>
    <meta content='<?php
                echo $seo_facebook_admin_id;
?>' property='fb:admins'/>
    <?php
            }
            if ($seo_facebook_show_title == 'on') {
?>
    <meta property="og:title" content="<?php
                echo the_title();
?>" />
    <?php
            }
            if ($seo_facebook_show_site_name == 'on') {
?>
    <meta property="og:site_name" content="<?php
                bloginfo('name');
?>" />
    <?php
            }
            if ($seo_facebook_show_url == 'on') {
?>
    <meta property="og:url" content="<?php
                the_permalink();
?>" />
    <?php
            }
            if ($seo_facebook_show_description == 'on') {
?>
    <meta property="og:description" content="<?php
                echo $seo_blog_description;
?>" />
    <?php
            }
            if ($seo_facebook_locale == 'on') {
?>
    <meta property="og:locale" content="<?php
                echo seo_fetch_locale('');
?>" />
    <?php
            }
            if ($seo_facebook_show_type == 'on') {
?>
    <meta property="og:type" content="<?php
                echo $seo_facebook_type;
?>" />
    <?php
            }
?>
    <meta property="og:updated_time" content="<?php
            the_modified_date();
?>" />
    <?php
            if ($seo_facebook_show_image == 'on') {
                if (is_single()) {
                    if ($facebook_image == "") {
                        $facebook_image = "http://www.artwithimpact.org/sites/default/files/images/icon_facebook_0.png";
                    }
                    $image = seo_get_open_graph_post_image($facebook_image);
?>
<meta property="og:image" content="<?php
                    echo $image;
?>"/>  
<?php
                } else {
                    if ($facebook_image == "") {
                        $facebook_image = "http://www.artwithimpact.org/sites/default/files/images/icon_facebook_0.png";
                    }
?>
    <meta property="og:image" content="<?php
                    echo $facebook_image;
?>"/>
    <?php
                }
            }
            //rew!
            if (is_single()) {
                if ($seo_facebook_publisher != "") {
?>
        <meta property="article:publisher" content="<?php
                    echo $seo_facebook_publisher;
?>" />
        <?php
                }
                if ($seo_facebook_author != "") {
?>
        <meta property="article:author" content="<?php
                    echo $seo_facebook_author;
?>" />
        <?php
                }
                if ($seo_facebook_show_times == 'on') {
?>
    <meta property="article:published_time" content="<?php
                    echo get_the_date();
?>" />
    <meta property="article:modified_time" content="<?php
                    echo the_modified_date();
?>" />
    <meta property="article:updated_time" content="<?php
                    echo the_modified_date();
?>" />
    <?php
                }
                if ($seo_facebook_show_sections == 'on') {
                    $cats = get_the_category();
                    if (!is_wp_error($cats) && (is_array($cats) && count($cats) > 0)) {
                        foreach ($cats as $cat) {
                            echo '<meta property="article:section" content="' . trim(esc_attr($cat->name)) . '"/>' . NL;
                        }
                    }
                }
            }
        }
        if ($seo_twitter == 'on') {
?>
<meta name="twitter:card" content="<?php
            echo $seo_twitter_type;
?>" />
<?php
            if ($seo_twitter_description == 'on') {
?>
<meta name="twitter:description" content="<?php
                echo $seo_blog_description;
?>" />
<?php
            }
            if ($seo_twitter_title == 'on') {
?>
<meta name="twitter:title" content="<?php
                the_title();
?>" />
<?php
            }
            if ($twitter_user != "") {
?>
<meta name="twitter:site" content="<?php
                echo gryphon_prepend_at_symbol($twitter_user);
?>" />
<?php
            }
            if ($seo_twitter_creator != "") {
?>
<meta name="twitter:creator" content="<?php
                echo gryphon_prepend_at_symbol($seo_twitter_creator);
?>" />
<?php
            }
            if ($seo_twitter_image_sw == 'on') {
                if (is_single()) {
                    if (has_post_thumbnail()) {
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
?> 
<meta name="twitter:image" content="<?php
                        echo $image[0];
?>"/>
<?php
                        if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                            echo $seo_twitter_image_alt;
?>"/>
<?php
                        }
                    } else {
                        if ($twitter_image != '') {
?>
<meta name="twitter:image" content="<?php
                            echo $twitter_image;
?>"/>
<?php
                        }
                        if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                            echo $seo_twitter_image_alt;
?>"/><?php
                        }
                    }
                } else {
                    if ($twitter_image != '') {
?>
<meta name="twitter:image" content="<?php
                        echo $twitter_image;
?>"/>
<?php
                    }
                    if ($seo_twitter_image_alt != '') {
?>
<meta name="twitter:image:alt" content="<?php
                        echo $seo_twitter_image_alt;
?>"/><?php
                    }
                }
            }
        }
        if($seo_google_en == 'on')
        {
            if($seo_google_analytics_id != "")
            {
        ?>
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

          ga('create', '<?php echo $seo_google_analytics_id;?>', 'auto');
          ga('send', 'pageview');

        </script>
        <?php
            }
        }
        echo "\r\n\r\n<!-- GRYPHON SEO TOOLS END -->\r\n\r\n";
    }
}
?>
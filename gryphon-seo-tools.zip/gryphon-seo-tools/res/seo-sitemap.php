<?php

function seo_create_sitemap()
{
    $seo_Sitemap_Settings = get_option('seo_Sitemap_Settings', false);
    if (isset($seo_Sitemap_Settings['seo_sitemap_number'])) {
        $seo_sitemap_number = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_number']));
    } else {
        $seo_sitemap_number = '1000';
    }
    if (str_replace('-', '', get_option('gmt_offset')) < 10) {
        $tempo = '-0' . str_replace('-', '', get_option('gmt_offset'));
    } else {
        $tempo = get_option('gmt_offset');
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_exclude'])) {
        $seo_sitemap_exclude = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_exclude']));
    } else {
        $seo_sitemap_exclude = '';
    }
    $seo_sitemap_robots_new = $seo_Sitemap_Settings['seo_sitemap_robots_new'];
    $seo_sitemap_htaccess_new = $seo_Sitemap_Settings['seo_sitemap_htaccess_new'];
    if (isset($seo_Sitemap_Settings['seo_sitemap_post_priority'])) {
        $seo_sitemap_post_priority = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_post_priority']));
    } else {
        $seo_sitemap_post_priority = '0.5';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_post_update'])) {
        $seo_sitemap_post_update = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_post_update']));
    } else {
        $seo_sitemap_post_update = 'daily';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_home_priority'])) {
        $seo_sitemap_home_priority = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_home_priority']));
    } else {
        $seo_sitemap_home_priority = '1.0';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_home_update'])) {
        $seo_sitemap_home_update = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_home_update']));
    } else {
        $seo_sitemap_home_update = 'weekly';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_posts'])) {
        $seo_sitemap_add_posts = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_add_posts']));
    } else {
        $seo_sitemap_add_posts = 'seo_YES';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_pages'])) {
        $seo_sitemap_add_pages = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_add_pages']));
    } else {
        $seo_sitemap_add_pages = 'seo_YES';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_att'])) {
        $seo_sitemap_add_att = esc_html(sanitize_text_field($seo_Sitemap_Settings['seo_sitemap_add_att']));
    } else {
        $seo_sitemap_add_att = 'seo_YES';
    }
    $seo_sitemap_google = $seo_Sitemap_Settings['seo_sitemap_google'];
    $seo_sitemap_robots = $seo_Sitemap_Settings['seo_sitemap_robots'];
    $arr = array();
    if ($seo_sitemap_add_posts == 'seo_YES') {
        $arr[] = 'post';
    }
    if ($seo_sitemap_add_pages == 'seo_YES') {
        $arr[] = 'page';
    }
    if ($seo_sitemap_add_att == 'seo_YES') {
        $arr[] = 'attachment';
    }
    if (strlen($tempo) == 3) {
        $tempo = $tempo . ':00';
    }
    $iteration  = 0;
    $allPosts   = get_posts(array(
        'numberposts' => -1,
        'orderby' => 'modified',
        'post_type' => $arr,
        'order' => 'DESC',
        'exclude' => $seo_sitemap_exclude
    ));
    $postNumber = count($allPosts);
    unset($allPosts);
    if ($seo_sitemap_robots_new == 'on') {
        $robots = ABSPATH . 'robots.txt';
        if (!file_exists($robots)) {
            try
            {
                $myfile = fopen($robots, "w");
                $txt    = "User-agent: *\r\nDisallow: /wp-admin/\r\nDisallow: /trackback/\r\nDisallow: /wp-content/plugins/\r\nDisallow: /readme.html";
                fwrite($myfile, $txt);
                fclose($myfile);
                sleep(1);
            } catch (Exception $e) {
                echo 'Caught exception robots: ',  $e->getMessage(), "\n";
            }
        }
    }
    if ($seo_sitemap_htaccess_new == 'on') {
        $htaccess = ABSPATH . '.htaccess';
        if (!file_exists($htaccess)) {
            try
            {
                $myfile2 = fopen($htaccess, "w");
                $txt2    = "# BEGIN WordPress/r/n<IfModule mod_rewrite.c>/r/nRewriteEngine On/r/nRewriteBase / /r/nRewriteRule ^index\.php$ - [L]/r/nRewriteCond %{REQUEST_FILENAME} !-f/r/nRewriteCond %{REQUEST_FILENAME} !-d/r/nRewriteRule . /index.php [L]/r/n</IfModule>/r/n# END WordPress";
                fwrite($myfile2, $txt2);
                fclose($myfile2);
            } catch (Exception $e) {
                echo 'Caught exception htaccess: ',  $e->getMessage(), "\n";
            }
        }
    }
    if ($seo_sitemap_robots == 'on') {
        $file3 = ABSPATH . 'robots.txt';
        if (file_exists($file3)) {
            try
            {
                $text3   = file_get_contents($file3);
                $lines   = explode("\n", $text3);
                $exclude = array();
                foreach ($lines as $line) {
                    if (stripos($line, 'sitemap') !== FALSE) {
                        continue;
                    }
                    $exclude[] = $line;
                }
                $text3 = implode("\n", $exclude);
                file_put_contents($file3, $text3);
            } catch (Exception $e) {
                echo 'Caught exception: ',  $e->getMessage(), "\n";
            }
        }
    }
    try
    {
        do {
            $sitemap         = "";
            $args            = array(
                'posts_per_page' => $seo_sitemap_number,
                'orderby' => 'modified',
                'post_type' => $arr,
                'order' => 'DESC',
                'offset' => ($iteration * $seo_sitemap_number),
                'exclude' => $seo_sitemap_exclude
            );
            $postsForSitemap = get_posts($args);
            $sitemap .= '<?xml version="1.0" encoding="UTF-8"?>' . '<?xml-stylesheet type="text/xsl" href="' . esc_url(home_url('/')) . 'sitemap.xsl"?>';
            $sitemap .= "\n" . '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            $sitemap .= "\t" . '<url>' . "\n" . "\t\t" . '<loc>' . esc_url(home_url('/')) . '</loc>' . "\n\t\t" . '<lastmod>' . date("Y-m-d\TH:i:s", current_time('timestamp', 0)) . $tempo . '</lastmod>' . "\n\t\t" . '<changefreq>' . $seo_sitemap_home_update . '</changefreq>' . "\n\t\t" . '<priority>' . $seo_sitemap_home_priority . '</priority>' . "\n\t" . '</url>' . "\n";
            foreach ($postsForSitemap as $post) {
                setup_postdata($post);
                $postdate = explode(" ", $post->post_modified);
                $sitemap .= "\t" . '<url>' . "\n" . "\t\t" . '<loc>' . get_permalink($post->ID) . '</loc>' . "\n\t\t" . '<lastmod>' . $postdate[0] . 'T' . $postdate[1] . $tempo . '</lastmod>' . "\n\t\t" . '<changefreq>' . $seo_sitemap_post_update . '</changefreq>' . "\n\t\t" . '<priority>' . $seo_sitemap_post_priority . '</priority>' . "\n\t" . '</url>' . "\n";
            }
            $sitemap .= '</urlset>';
            $sitemapName = "";
            if ($iteration == 0) {
                $sitemapName = "sitemap.xml";
                $fp          = fopen(ABSPATH . "sitemap.xml", 'w');
            } else {
                $sitemapName = "sitemap_" . ($iteration + 1) . ".xml";
                $fp          = fopen(ABSPATH . "sitemap_" . ($iteration + 1) . ".xml", 'w');
            }
            fwrite($fp, $sitemap);
            fclose($fp);
            $iteration++;
            $postNumber = (int) $postNumber - (int) $seo_sitemap_number;
            if ($seo_sitemap_google == 'on') {
                shell_exec('ping -c1 www.google.com/webmasters/sitemaps/ping?sitemap=' . get_site_url() . '/' . $sitemapName);
                shell_exec('ping -c1 http://www.bing.com/webmaster/ping.aspx?siteMap=' . get_site_url() . '/' . $sitemapName);
                shell_exec('ping -c1 http://submissions.ask.com/ping?sitemap=' . get_site_url() . '/' . $sitemapName);
            }
            if ($seo_sitemap_robots == 'on') {
                $file = ABSPATH . 'robots.txt';
                if (file_exists($file)) {
                    $text   = file_get_contents($file);
                    $line   = explode("\n", $text);
                    $line[] = "Sitemap: " . get_site_url() . '/' . $sitemapName;
                    $text   = implode("\n", $line);
                    file_put_contents($file, $text);
                }
            }
        } while ((int) $postNumber > 0);
    } catch (Exception $e) {
        echo 'Caught exception sitemap loop: ',  $e->getMessage(), "\n";
    }
}
function seo_delete_sitemap()
{
    
    $file = ABSPATH . "sitemap*.xml";
    foreach (glob($file) as $filename) {
        unlink($filename);
    }
}

function seo_sitemap()
{
?>
    <div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group10');
    do_settings_sections('seo_option_group10');
    $seo_Sitemap_Settings = get_option('seo_Sitemap_Settings', false);
    $seo_sitemap_enabled = $seo_Sitemap_Settings['seo_sitemap_enabled'];
    if (isset($seo_Sitemap_Settings['seo_sitemap_post_priority'])) {
        $seo_sitemap_post_priority = $seo_Sitemap_Settings['seo_sitemap_post_priority'];
    } else {
        $seo_sitemap_post_priority = '0.5';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_post_update'])) {
        $seo_sitemap_post_update = $seo_Sitemap_Settings['seo_sitemap_post_update'];
    } else {
        $seo_sitemap_post_update = 'daily';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_home_priority'])) {
        $seo_sitemap_home_priority = $seo_Sitemap_Settings['seo_sitemap_home_priority'];
    } else {
        $seo_sitemap_home_priority = '1.0';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_home_update'])) {
        $seo_sitemap_home_update = $seo_Sitemap_Settings['seo_sitemap_home_update'];
    } else {
        $seo_sitemap_home_update = 'weekly';
    }
    $seo_sitemap_google = $seo_Sitemap_Settings['seo_sitemap_google'];
    $seo_sitemap_robots = $seo_Sitemap_Settings['seo_sitemap_robots'];
    $seo_sitemap_robots_new = $seo_Sitemap_Settings['seo_sitemap_robots_new'];
    $seo_sitemap_htaccess_new = $seo_Sitemap_Settings['seo_sitemap_htaccess_new'];
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_posts'])) {
        $seo_sitemap_add_posts = $seo_Sitemap_Settings['seo_sitemap_add_posts'];
    } else {
        $seo_sitemap_add_posts = 'seo_YES';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_pages'])) {
        $seo_sitemap_add_pages = $seo_Sitemap_Settings['seo_sitemap_add_pages'];
    } else {
        $seo_sitemap_add_pages = 'seo_YES';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_add_att'])) {
        $seo_sitemap_add_att = $seo_Sitemap_Settings['seo_sitemap_add_att'];
    } else {
        $seo_sitemap_add_att = 'seo_YES';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_exclude'])) {
        $seo_sitemap_exclude = $seo_Sitemap_Settings['seo_sitemap_exclude'];
    } else {
        $seo_sitemap_exclude = '';
    }
    if (isset($seo_Sitemap_Settings['seo_sitemap_number'])) {
        $seo_sitemap_number = $seo_Sitemap_Settings['seo_sitemap_number'];
        $min                = 1;
        $max                = 50000;
        
        if (filter_var($seo_sitemap_number, FILTER_VALIDATE_INT, array(
            "options" => array(
                "min_range" => $min,
                "max_range" => $max
            )
        )) === false) {
            $seo_Sitemap_Settings['seo_sitemap_number'] = 1000;
            update_option('seo_Sitemap_Settings', $seo_Sitemap_Settings);
            $seo_sitemap_number = '1000';
        } else {
            //ok, variable is int in range
        }
    } else {
        $seo_Sitemap_Settings['seo_sitemap_number'] = 1000;
        update_option('seo_Sitemap_Settings', $seo_Sitemap_Settings);
        $seo_sitemap_number = '1000';
    }
    if ($seo_sitemap_enabled == 'on') {
        seo_create_sitemap();
        add_action('wpmu_new_blog', 'seo_create_sitemap');
        add_action('activate_blog', 'seo_create_sitemap');
        add_action('make_undelete_blog', 'seo_create_sitemap');
        add_action('unarchive_blog', 'seo_create_sitemap');
        add_action('make_ham_blog', 'seo_create_sitemap');
        add_action('save_post', 'seo_create_sitemap');
        add_action('trashed_post ', 'seo_create_sitemap');
        
        add_action('delete_blog', 'seo_delete_sitemap');
        add_action('deactivate_blog', 'seo_delete_sitemap');
        add_action('make_delete_blog', 'seo_delete_sitemap');
        add_action('archive_blog', 'seo_delete_sitemap');
        add_action('make_spam_blog', 'seo_delete_sitemap');
    } else {
        seo_delete_sitemap();
    }
?><script>
                var seo_admin_json = {    
                    seo_sitemap_enabled: '<?php
    echo $seo_sitemap_enabled;
?>',
                    seo_sitemap_number: '<?php
    echo $seo_sitemap_number;
?>',
                    seo_sitemap_exclude: '<?php
    echo $seo_sitemap_exclude;
?>',
                    seo_sitemap_add_posts: '<?php
    echo $seo_sitemap_add_posts;
?>',
                    seo_sitemap_add_pages: '<?php
    echo $seo_sitemap_add_pages;
?>',
                    seo_sitemap_home_priority: '<?php
    echo $seo_sitemap_home_priority;
?>',
                    seo_sitemap_home_update: '<?php
    echo $seo_sitemap_home_update;
?>',
                    seo_sitemap_post_priority: '<?php
    echo $seo_sitemap_post_priority;
?>',
                    seo_sitemap_post_update: '<?php
    echo $seo_sitemap_post_update;
?>',
                    seo_sitemap_add_att: '<?php
    echo $seo_sitemap_add_att;
?>'}
            </script>
            <script type="text/javascript">
    window.onload = sChanged;
    function sChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".hideMap").show();
        else
            jQuery(".hideMap").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
            <div class="gs_popuptype_holder">
            <table>
            <tr>
            <td>
                <span class="gs-sub-heading"><b>Enable Sitemap Feature:</b></span>
                Adds the <a href="https://support.google.com/webmasters/answer/156184?rd=1" target="_blank">XML Sitemap</a> to your site.
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "A sitemap is a file where you can list the web pages of your site to tell Google and other search engines about the organization of your site content. Search engine web crawlers like Googlebot read this file to more intelligently crawl your site. This plugin automatically generates one for you.";
?>
                                </div>
                            </div>
                </td>
                <td>
                <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_sitemap_enabled" name="seo_Sitemap_Settings[seo_sitemap_enabled]" onchange="sChanged()"<?php
    if ($seo_sitemap_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="seo_sitemap_enabled"></label>
                </div>
                </td>
                <td>
                <?php
    if ($seo_sitemap_enabled == 'on') {
?><a href="<?php
        echo get_site_url() . '/sitemap.xml';
?>" target="_blank"> View your sitemap</a><?php
    }
?>
                </td>
                </tr>
                </table>
                <div class="hideMap">
        <hr/><b>Sitemap Settings:</b><br/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                Maximum entries per site map:
                <input type="text" name="seo_Sitemap_Settings[seo_sitemap_number]" ng-model="settings.seo_sitemap_number" size="3" required>
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                    <div class="bws_hidden_help_text" style="min-width: 260px;">
                        <?php
    echo "Gryphon Seo Tools will generate more sitemaps if number of posts exceed this number (must be integer between 1 and 50000).";
?>
                    </div>
                </div>
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                Exclude post IDs from site map:
                <input type="text" name="seo_Sitemap_Settings[seo_sitemap_exclude]" ng-model="settings.seo_sitemap_exclude" size="3">
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                    <div class="bws_hidden_help_text" style="min-width: 260px;">
                       <?php
    echo "Exclude post IDs from site map";
?>
                    </div>
                </div>
            </div>
        </div>
        <div>
        Home page priority:
        <select name="seo_Sitemap_Settings[seo_sitemap_home_priority]" ng-model="settings.seo_sitemap_home_priority">
          <option value="0.0">0.0</option>
          <option value="0.1">0.1</option>
          <option value="0.2">0.2</option>
          <option value="0.3">0.3</option>
          <option value="0.4">0.4</option>
          <option value="0.5">0.5</option>
          <option value="0.6">0.6</option>
          <option value="0.7">0.7</option>
          <option value="0.8">0.8</option>
          <option value="0.9">0.9</option>
          <option value="1.0">1.0</option>
        </select>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The priority of this URL relative to other URLs on your site. Valid values range from 0.0 to 1.0. This value does not affect how your pages are compared to pages on other sites—it only lets the search engines know which pages you deem most important for the crawlers. We recommand setting this to 1.0.";
?>
                        </div>
                    </div>
        </div>
        <div>
        Posts priority:
        <select name="seo_Sitemap_Settings[seo_sitemap_post_priority]" ng-model="settings.seo_sitemap_post_priority">
          <option value="0.0">0.0</option>
          <option value="0.1">0.1</option>
          <option value="0.2">0.2</option>
          <option value="0.3">0.3</option>
          <option value="0.4">0.4</option>
          <option value="0.5">0.5</option>
          <option value="0.6">0.6</option>
          <option value="0.7">0.7</option>
          <option value="0.8">0.8</option>
          <option value="0.9">0.9</option>
          <option value="1.0">1.0</option>
        </select>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "The priority of this URL relative to other URLs on your site. Valid values range from 0.0 to 1.0. This value does not affect how your pages are compared to pages on other sites—it only lets the search engines know which pages you deem most important for the crawlers. We recommand setting this to 0.5.";
?>
                        </div>
                    </div>
        </div>
        <div>
        Posts update frequency:
        <select name="seo_Sitemap_Settings[seo_sitemap_post_update]" ng-model="settings.seo_sitemap_post_update">
          <option value="always">always</option>
          <option value="hourly">hourly</option>
          <option value="daily">daily</option>
          <option value="weekly">weekly</option>
          <option value="monthly">monthly</option>
          <option value="yearly">yearly</option>
          <option value="never">never</option>
        </select>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "How frequently the page is likely to change. This value provides general information to search engines and may not correlate exactly to how often they crawl the page. We recommend setting this to weekly.";
?>
                        </div>
                    </div>
        </div>
        <div>
        Home page update frequency:
        <select name="seo_Sitemap_Settings[seo_sitemap_home_update]" ng-model="settings.seo_sitemap_home_update">
          <option value="always">always</option>
          <option value="hourly">hourly</option>
          <option value="daily">daily</option>
          <option value="weekly">weekly</option>
          <option value="monthly">monthly</option>
          <option value="yearly">yearly</option>
          <option value="never">never</option>
        </select>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "How frequently the page is likely to change. This value provides general information to search engines and may not correlate exactly to how often they crawl the page. We recommend setting this to daily.";
?>
                        </div>
                    </div>
        </div>
        <span class="gs-sub-heading">Include Posts in Site Map:&nbsp;&nbsp;&nbsp;</span>
                        
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_posts]" value="seo_YES"
                            id="radio_seoi_yes" ng-model="settings.seo_sitemap_add_posts"> include</label>&nbsp; 
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_posts]" value="seo_NO" 
                            id="radio_seoi_no" ng-model="settings.seo_sitemap_add_posts"> exclude</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Add posts to the sitemap? We strongly recommend to leave this enabled.";
?>
                                </div>
                            </div>
                        <br/>
                        <span class="gs-sub-heading">Include Pages in Site Map:&nbsp;&nbsp;&nbsp;</span>
                        
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_pages]" value="seo_YES"
                            id="radio_seoi_yes" ng-model="settings.seo_sitemap_add_pages"> include</label>&nbsp; 
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_pages]" value="seo_NO" 
                            id="radio_seoi_no" ng-model="settings.seo_sitemap_add_pages"> exclude</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Add pages to the sitemap? We strongly recommend to leave this enabled.";
?>
                                </div>
                            </div>
                        <br/>
                        <span class="gs-sub-heading">Include Attachments in Site Map:&nbsp;&nbsp;&nbsp;</span>
                        
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_att]" value="seo_YES"
                            id="radio_seoi_yes" ng-model="settings.seo_sitemap_add_att"> include</label>&nbsp; 
                        <label><input type="radio" name="seo_Sitemap_Settings[seo_sitemap_add_att]" value="seo_NO" 
                            id="radio_seoi_no" ng-model="settings.seo_sitemap_add_att"> exclude</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Add attachments to the sitemap? This has little to no SEO value. You can change it as you consider.";
?>
                                </div>
                            </div>
                        <br/>
                        <span class="gs-sub-heading">Ping Search engines (Google, Bing, Ask) on sitemap change:</span>
                        <input type="checkbox" id="seo_sitemap_google" name="seo_Sitemap_Settings[seo_sitemap_google]"<?php
    if ($seo_sitemap_google == 'on')
        echo ' checked ';
?>>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Whenever you publish a new post, or make changes to your site structure which updates the sitemap of your website, it is advisable that you submit the updated sitemap to the search engines like Google & Bing to tell them about the updated content.";
?>
                                </div>
                            </div>
                        <br/>
                        <span class="gs-sub-heading">Create .htaccess if it does not exist:</span>
                        <input type="checkbox" id="seo_sitemap_htaccess_new" name="seo_Sitemap_Settings[seo_sitemap_htaccess_new]"<?php
    if ($seo_sitemap_htaccess_new == 'on')
        echo ' checked ';
?>>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo ".htaccess is a configuration file for use on web servers running the Apache Web Server software. When a .htaccess file is placed in a directory which is in turn 'loaded via the Apache Web Server', then the .htaccess file is detected and executed by the Apache Web Server software. We recommend to leave this checled.";
?>
                                </div>
                            </div>                        
                        <br/>
                        <span class="gs-sub-heading">Create robots.txt if it does not exist:</span>
                        <input type="checkbox" id="seo_sitemap_robots_new" name="seo_Sitemap_Settings[seo_sitemap_robots_new]"<?php
    if ($seo_sitemap_robots_new == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Web site owners use the /robots.txt file to give instructions about their site to web robots; this is called The Robots Exclusion Protocol. We recommend to leave this checled.";
?>
                                </div>
                            </div>
                        <br/>
                        <span class="gs-sub-heading">Add link of sitemap to robots.txt:</span>
                        <input type="checkbox" id="seo_sitemap_robots" name="seo_Sitemap_Settings[seo_sitemap_robots]"<?php
    if ($seo_sitemap_robots == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "This setting will add a link of your sitemap to robots.txt, so crawling bots will find your sitemap with ease.";
?>
                                </div>
                            </div>
                            </div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit0" id="btnSubmit" class="button button-primary" value="Save"/></p></div>  
    </form>
</div>
</div>
</div>
     <?php
}
?>
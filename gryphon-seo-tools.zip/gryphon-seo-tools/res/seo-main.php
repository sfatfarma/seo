<?php

function seo_remove_script_version($src)
{
    $parts = explode('?ver', $src);
    return $parts[0];
}
function seo_remove_script_version2($src)
{
    $parts = explode('&ver', $src);
    return $parts[0];
}

function fwd_seo_admin_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group');
    do_settings_sections('seo_option_group');
    $seo_general_settings = get_option('seo_General_Settings', false);
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
?><script>
                var seo_admin_json = {    
                    popupenabled: '<?php
    echo $activatedRadioValue;
?>'}
            </script>
            <script type="text/javascript">
    window.onload = mainChanged;
    function mainChanged()
    {
        if(jQuery('.mainEnable').is(":checked"))   
            jQuery(".hideMain").show();
        else
            jQuery(".hideMain").hide();
    }
    
    </script>
    <script>
    function resetClick()
    {
        jQuery('.button').click(function() {
            jQuery.ajax({
                type: "POST",
                url: "/wp-admin/admin-ajax.php",
                data: "addCustomer"
            }).done(function( msg ) {
            });    
        });
    }
</script>

            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div>
                    <div>
                        <span class="gs-sub-heading"><b>Gryphon SEO Tools:</b>&nbsp;&nbsp;&nbsp;</span>
                        <label><input class="mainEnable" type="radio" name="seo_General_Settings[seo_activated_radio]" value="seo_YES"
                            id="radio_seo_yes" ng-model="settings.popupenabled" onchange="mainChanged()"> <b>Enable Plugin</b></label>&nbsp; 
                        <label><input type="radio" name="seo_General_Settings[seo_activated_radio]" value="seo_NO" 
                            id="radio_seo_no" ng-model="settings.popupenabled" onchange="mainChanged()"> <b>Disable Plugin</b></label>
                        <hr/>
                    </div>
                    <div>
                        <img src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/banner.jpg';
?>" alt="Gryphon SEO Tools">
                    </div>
                        <script type="text/javascript" >
                        function resetClick()
                        {
                            if (confirm("Are you sure you want to reset all plugin settings to their default values?") == true) {
                                var data = {
                                    action: 'my_action'
                                };
                                jQuery.post(ajaxurl, data, function(response) {
                                });
                            } else {
                                return;
                            }
                        }
                        </script>
                    <b>Restore default settings:</b> <input type="button" name="but" id="but" value="Restore Defaults" onclick="resetClick()"/>
                    <br/>
                    <div class="box">
                    <h3>Useful checks:</h3>
                    <table><tr><td><a href="https://developers.google.com/speed/pagespeed/insights/?url=<?php
    echo get_home_url();
?>&tab=mobile" target="_blank">Check your page performance score!</a></td></tr><tr><td>
                    <a href="https://validator.w3.org/nu/?doc=<?php
    echo get_home_url();
?>" target="_blank">Check your page HTML validity!</a></td></tr></table>
                    </div>
                </div>   
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
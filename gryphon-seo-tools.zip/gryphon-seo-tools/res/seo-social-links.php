<?php
function fwd_seo_social_links_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group3');
    do_settings_sections('seo_option_group3');
    $seo_Social_Links_Settings = get_option('seo_Social_Links_Settings', false);
    if (isset($seo_Social_Links_Settings['seo_facebook_profile'])) {
        $seo_facebook_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_facebook_profile']));
    } else {
        $seo_facebook_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_social_links'])) {
        $seo_social_links = $seo_Social_Links_Settings['seo_social_links'];
    } else {
        $seo_social_links = '';
    }
    if (isset($seo_Social_Links_Settings['seo_twitter_profile'])) {
        $seo_twitter_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_twitter_profile']));
    } else {
        $seo_twitter_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_gplus_profile'])) {
        $seo_gplus_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_gplus_profile']));
    } else {
        $seo_gplus_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_instagram_profile'])) {
        $seo_instagram_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_instagram_profile']));
    } else {
        $seo_instagram_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_tumblr_profile'])) {
        $seo_tumblr_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_tumblr_profile']));
    } else {
        $seo_tumblr_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_pinterest_profile'])) {
        $seo_pinterest_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_pinterest_profile']));
    } else {
        $seo_pinterest_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_linkedin_profile'])) {
        $seo_linkedin_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_linkedin_profile']));
    } else {
        $seo_linkedin_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_soundcloud_profile'])) {
        $seo_soundcloud_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_soundcloud_profile']));
    } else {
        $seo_soundcloud_profile = '';
    }
    if (isset($seo_Social_Links_Settings['seo_youtube_profile'])) {
        $seo_youtube_profile = esc_html(sanitize_text_field($seo_Social_Links_Settings['seo_youtube_profile']));
    } else {
        $seo_youtube_profile = '';
    }
?><script>
                var seo_admin_json = {    
                    seo_facebook_profile: '<?php
    echo $seo_facebook_profile;
?>',
                    seo_twitter_profile: '<?php
    echo $seo_twitter_profile;
?>',
                    seo_gplus_profile: '<?php
    echo $seo_gplus_profile;
?>',
                    seo_youtube_profile: '<?php
    echo $seo_youtube_profile;
?>',
                    seo_instagram_profile: '<?php
    echo $seo_instagram_profile;
?>',
                    seo_tumblr_profile: '<?php
    echo $seo_tumblr_profile;
?>',
                    seo_soundcloud_profile: '<?php
    echo $seo_soundcloud_profile;
?>',
                    seo_linkedin_profile: '<?php
    echo $seo_linkedin_profile;
?>',
                    seo_pinterest_profile: '<?php
    echo $seo_pinterest_profile;
?>'
                    }
            </script>
            <script type="text/javascript">
    window.onload = slChanged;
    function slChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".slHide").show();
        else
            jQuery(".slHide").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
    <span class="gs-sub-heading"><b>Social Links:</b></span>
    </td>
    <td>
    <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_social_links" name="seo_Social_Links_Settings[seo_social_links]" onchange="slChanged()"<?php
    if ($seo_social_links == 'on')
        echo ' checked ';
?>>
                            <label for="seo_social_links"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <div class="slHide">
                    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Facebook:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Facebook profile link. Get it <a href='https://facebook.com/me' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_facebook_profile]" ng-model="settings.seo_facebook_profile" size="68" placeholder="https://www.facebook.com/your_id">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Twitter:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Twitter profile link. Get it <a href='https://twitter.com/home' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_twitter_profile]" ng-model="settings.seo_twitter_profile" size="68" placeholder="https://twitter.com/your_id">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Google Plus:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Google Plus profile link. Get it <a href='https://plus.google.com/me' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_gplus_profile]" ng-model="settings.seo_gplus_profile" size="68" placeholder="https://plus.google.com/me">
            </div>
        </div>  
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Pinterest:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Pinterest profile link. Get it <a href='https://www.pinterest.com/me/' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_pinterest_profile]" ng-model="settings.seo_pinterest_profile" size="68" placeholder="https://www.pinterest.com/me/">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Instagram:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Instagram profile link. Get it <a href='https://instagram.com/' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_instagram_profile]" ng-model="settings.seo_instagram_profile" size="68" placeholder="https://www.instagram.com/">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Youtube:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Youtube profile link. Get it <a href='https://www.youtube.com/user/%2f' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_youtube_profile]" ng-model="settings.seo_youtube_profile" size="68" placeholder="https://www.youtube.com/user/%2f">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    LinkedIn:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your LinkedIn profile link. Get it <a href='https://www.linkedin.com/profile/view' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_linkedin_profile]" ng-model="settings.seo_linkedin_profile" size="68" placeholder="https://www.linkedin.com/profile/view">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Tumblr:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your Tumblr profile link. Get it <a href='https://www.tumblr.com/dashboard' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_tumblr_profile]" ng-model="settings.seo_tumblr_profile" size="68" placeholder="https://www.tumblr.com/dashboard">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    SoundCloud:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Here you should add your SoundCloud profile link. Get it <a href='https://soundcloud.com/you' target='_blank'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Social_Links_Settings[seo_soundcloud_profile]" ng-model="settings.seo_soundcloud_profile" size="68" placeholder="https://soundcloud.com/you">
            </div>
        </div>
        </div>
    </div> 
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
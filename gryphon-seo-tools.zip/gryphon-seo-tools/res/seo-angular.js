angular.module('seosettingsApp', ['ngSanitize'])
.controller('seosettingsController', function($scope, $sce) {
    $scope.settings = seo_admin_json;
});
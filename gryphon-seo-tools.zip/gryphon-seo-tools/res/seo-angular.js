angular.module('seosettingsApp', ['ngSanitize'])
.controller('seosettingsController', function($scope) {
    $scope.settings = seo_admin_json;
    $scope.regex = '/(?:http:\/\/)?(?:www\.)?facebook\.com\/(?:(?:\w)*#!\/)?(?:pages\/)?(?:[\w\-]*\/)*([\w\-]*)/';
});
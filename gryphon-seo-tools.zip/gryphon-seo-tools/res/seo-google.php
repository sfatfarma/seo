<?php
function fwd_seo_google_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group8');
    do_settings_sections('seo_option_group8');
    $seo_Google_Settings = get_option('seo_Google_Settings', false);
    if (isset($seo_Google_Settings['seo_google_publisher'])) {
        $seo_google_publisher = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_publisher']));
    } else {
        $seo_google_publisher = '';
    }
    if (isset($seo_Google_Settings['seo_google_en'])) {
        $seo_google_en = $seo_Google_Settings['seo_google_en'];
    } else {
        $seo_google_en = '';
    }
    if (isset($seo_Google_Settings['seo_google_author'])) {
        $seo_google_author = esc_html(sanitize_text_field($seo_Google_Settings['seo_google_author']));
    } else {
        $seo_google_author = '';
    }
?><script>
                var seo_admin_json = {    
                    google_publisher: '<?php
    echo $seo_google_publisher;
?>',
                    seo_google_author: '<?php
    echo $seo_google_author;
?>'
                    }
            </script>
            <script type="text/javascript">
    window.onload = mChanged;
    function mChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".mainHi").show();
        else
            jQuery(".mainHi").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Google Meta Tags:</b></span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable Google specific meta tags.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_google_en" name="seo_Google_Settings[seo_google_en]" onchange="mChanged()"<?php
    if ($seo_google_en == 'on')
        echo ' checked ';
?>>
                            <label for="seo_google_en"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <div class="mainHi">
                    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Google Publisher Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Rel=publisher is an industry standard meta tag, used to mark which is the publishers official page (like Google+ page) for sharing official information. Here you should add a link to your Google Plus account.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Google_Settings[seo_google_publisher]" ng-model="settings.google_publisher" size="68" placeholder="https://plus.google.com/123456789012345678901">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Google Author Link:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "If you are a frequent blogger or writer, you can claim your hard work as your own and build a reputation for being an expert on your subject. Here you should add a link to your google plus account.";
?>
                        </div>
                    </div>
                </div>
                <input type="url" validator="url" name="seo_Google_Settings[seo_google_author]" ng-model="settings.seo_google_author" size="68" placeholder="https://plus.google.com/123456789012345678901">
            </div>
        </div>
</div>
</div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
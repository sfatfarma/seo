<?php
function seo_google_analytics()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group12');
    do_settings_sections('seo_option_group12');
    $seo_Analytics = get_option('seo_Analytics', false);
    if (isset($seo_Analytics['seo_google_analytics_id'])) {
        $seo_google_analytics_id = esc_html(sanitize_text_field($seo_Analytics['seo_google_analytics_id']));
    } else {
        $seo_google_analytics_id = '';
    }
    $seo_google_en = $seo_Analytics['seo_google_en'];
?><script>
                var seo_admin_json = {    
                    seo_google_analytics_id: '<?php
    echo $seo_google_analytics_id;
?>'
                    }
            </script>
            <script type="text/javascript">
    window.onload = mChanged;
    function mChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".mainHi").show();
        else
            jQuery(".mainHi").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Google meta tags:</b></span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable Google Analytics code inclusion.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_google_en" name="seo_Analytics[seo_google_en]" onchange="mChanged()"<?php
    if ($seo_google_en == 'on')
        echo ' checked ';
?>>
                            <label for="seo_google_en"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <div class="mainHi">
                    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Google Analytics tracking ID:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Add your tracking ID, from Google Analytics. Information on how to get it, you can find <a href='https://support.google.com/analytics/answer/1008080?hl=en'>here</a>.";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Analytics[seo_google_analytics_id]" ng-model="settings.seo_google_analytics_id" size="68" placeholder="UA-########-#">
            </div>
        </div>
</div>
</div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
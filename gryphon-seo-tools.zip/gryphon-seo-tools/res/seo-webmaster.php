<?php
function fwd_seo_validation_codes_settings()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('seo_option_group4');
    do_settings_sections('seo_option_group4');
    $seo_Validation_Codes_Settings = get_option('seo_Validation_Codes_Settings', false);
    if (isset($seo_Validation_Codes_Settings['seo_google_code'])) {
        $seo_google_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_google_code']));
    } else {
        $seo_google_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_validation_codes'])) {
        $seo_validation_codes = $seo_Validation_Codes_Settings['seo_validation_codes'];
    } else {
        $seo_validation_codes = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_bing_code'])) {
        $seo_bing_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_bing_code']));
    } else {
        $seo_bing_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_yandex_code'])) {
        $seo_yandex_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_yandex_code']));
    } else {
        $seo_yandex_code = '';
    }
    if (isset($seo_Validation_Codes_Settings['seo_pinterest_code'])) {
        $seo_pinterest_code = esc_html(sanitize_text_field($seo_Validation_Codes_Settings['seo_pinterest_code']));
    } else {
        $seo_pinterest_code = '';
    }
?><script>
                var seo_admin_json = {    
                    google_code: '<?php
    echo $seo_google_code;
?>',
                    bing_code: '<?php
    echo $seo_bing_code;
?>',
                    yandex_code: '<?php
    echo $seo_yandex_code;
?>',
                    facebook_app_id: '<?php
    echo $seo_facebook_app_id;
?>',
                    pinterest_code: '<?php
    echo $seo_pinterest_code;
?>'
                    }
            </script>
            <script type="text/javascript">
    window.onload = wmChanged;
    function wmChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".wmHide").show();
        else
            jQuery(".wmHide").hide();
    }
</script>
            <div ng-app="seosettingsApp" ng-controller="seosettingsController" ng-cloak ng-init="initialized()">
                <div class="gs_admin_main_table">
<div class="gs_popuptype_holder">
    <div class="gs_border">
    <table>
    <tr>
    <td>
    <span class="gs-sub-heading"><b>Webmaster Validation Codes:</b></span>
    </td>
    <td>
    <div class="slideThree">
                            <input class="input-checkbox" type="checkbox" id="seo_validation_codes" name="seo_Validation_Codes_Settings[seo_validation_codes]" onchange="wmChanged()"<?php
                        if ($seo_validation_codes == 'on')
                            echo ' checked ';
                        ?>>
                            <label for="seo_validation_codes"></label>
    </div>
    </td>
    </tr>
    </table>
    <div class="wmHide">
    <hr/>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Google Webmaster Tools:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
        echo "Here you should add your Google Webmaster Tools verification code";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Validation_Codes_Settings[seo_google_code]" ng-model="settings.google_code" size="68">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Bing Webmaster Tools:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
        echo "Here you should add your Bing Webmaster Tools verification code";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Validation_Codes_Settings[seo_bing_code]" ng-model="settings.bing_code" size="68">
            </div>
        </div>
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Yandex Webmaster Tools:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
        echo "Here you should add your Yandex Webmaster Tools verification code";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Validation_Codes_Settings[seo_yandex_code]" ng-model="settings.yandex_code" size="68">
            </div>
        </div>  
        <div class="gs_radio_related_row">
            <div class="gs_radio_related_cell">
                <div>
                    Pinterest Confirmation Code:
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
        echo "Here you should add your Pinterest verification code";
?>
                        </div>
                    </div>
                </div>
                <input type="text" name="seo_Validation_Codes_Settings[seo_pinterest_code]" ng-model="settings.pinterest_code" size="68">
            </div>
        </div>
        </div>
    </div>
</div>
</div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>
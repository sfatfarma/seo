<?php

function seo_file_editor()
{
    ?>
    <?php

$url = ABSPATH . "admin.php?page=seo_file_editor";

$file2 = ABSPATH . '.htaccess';

if (isset($_POST['text2']))
{
    file_put_contents($file2, stripslashes($_POST['text2']));
}
if(file_exists($file2))
{
    $text2 = file_get_contents($file2);
}
else
{
    $text2 = ".HTACCESS file does not exist! Create it from sitemap menu page!";
}

?>
<script>
function reset1() {
    document.getElementById("text2").value = `# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /wp/
RewriteRule ^index.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /wp/index.php [L]
</IfModule>

# END WordPress`;
}
function reset2() {
    document.getElementById("text3").value = `User-agent: *
Disallow: /wp-admin/
Disallow: /trackback/
Disallow: /wp-content/plugins/
Disallow: /readme.html
Sitemap: http://localhost/wp/sitemap.xml`;
}
</script>
<div class="gs_popuptype_holder">
<table>
<tr>
<td>
<b>.HTACCESS</b>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
    <div class="bws_hidden_help_text" style="min-width: 260px;">
        <?php
        echo ".htaccess is a configuration file for use on web servers running the Apache Web Server software. When a .htaccess file is placed in a directory which is in turn 'loaded via the Apache Web Server', then the .htaccess file is detected and executed by the Apache Web Server software.. Change this only if you know what you are doing!";
        ?>
    </div>
</div>
<form action="" method="post">
<textarea rows="30" cols="90" id="text2" name="text2"><?php echo stripslashes(htmlspecialchars($text2)); ?></textarea><br/>
<input type="submit" />
<input type="button" value="Reset" onclick="javascript:reset1();" />
</form>
<?php
$file3 = ABSPATH . 'robots.txt';

if (isset($_POST['text3']))
{
    file_put_contents($file3, $_POST['text3']);
}
if(file_exists($file2))
{
    $text3 = file_get_contents($file3);
}
else
{
    $text2 = "Robots.txt file does not exist! Create it from sitemap menu page!";
}
?>
</td>
<td>
<b>ROBOTS.TXT</b>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
    <div class="bws_hidden_help_text" style="min-width: 260px;">
        <?php
        echo "Web site owners use the /robots.txt file to give instructions about their site to web robots; this is called The Robots Exclusion Protocol. Change this only if you know what you are doing!";
        ?>
    </div>
</div>
<form action="" method="post">
<textarea rows="30" cols="90" id="text3" name="text3"><?php echo stripslashes(htmlspecialchars($text3)); ?></textarea><br/>
<input type="submit" />
<input type="button" value="Reset" onclick="javascript:reset2();" />
</form>
</td>
</tr>
</table>
</div>
<?php
}
?>
<?php

function seo_w3c_validator()
{
    if ( function_exists('w3c_check_validation') ) { w3c_check_validation();}
}

?>
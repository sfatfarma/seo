<?php
class W3CPageValidationApi{
 
	var $BaseUrl = 'http://validator.w3.org/check';
	var $Output = 'soap12'; //Set the type of output you want, default = soap12 or web
	var $Uri = '';
	var $Feedback;
	var $CallUrl = '';
	var $ValidResult = false;
	var $ValidErrors = 0;
	var $Sleep = 1; //Default sleeptime is 1 sec after API call
	var $SilentUi = false; //Set to false to prevent echo the vidual display
	var $Ui = '';
 
	function W3CPageValidationApi(){
		//Nothing...
	}
	
	function makeCallUrl(){
		$this->CallUrl = $this->BaseUrl . "?output=" . $this->Output . "&uri=" . $this->Uri;
	}
	
	function setUri($uri){
		$this->Uri = $uri;
		$this->makeCallUrl();
	}
	
	function makeValidationCall(){
		if($this->CallUrl != '' && $this->Uri != '' && $this->Output != ''){
			$this->CallUrl;
			$handle = fopen($this->CallUrl, "rb");
            if($handle == FALSE)
            {
                return false;
            }
			$contents = '';
			while (!feof($handle)) {
				$contents .= fread($handle, 8192);
			}
			fclose($handle);
			$this->Feedback = $contents;
			sleep($this->Sleep);
			return $contents;
		} else {
			return false;
		}
	}
	
	function validate($uri){
		if($uri != ''){
			$this->setUri($uri);
		} else {
			$this->makeCallUrl();
		}
		
		if($this->makeValidationCall() == false)
        {
            $result = false;
        }
        else
        {
            $a = strpos($this->Feedback, '<m:validity>', 0)+12;
            $b = strpos($this->Feedback, '</m:validity>', $a);
            $result = substr($this->Feedback, $a, $b-$a);
            if($result == 'true'){
                $result = true;
            } else {
                $result = false;
            }
            $this->ValidResult = $result;
        }
		
		if($result){
			return $result;
		} else {
			//<m:errorcount>3</m:errorcount>
			$a = strpos($this->Feedback, '<m:errorcount>', $a)+14;
			$b = strpos($this->Feedback, '</m:errorcount>', $a);
			$errors = substr($this->Feedback, $a, $b-$a);
			$this->ValidErrors = $errors;
		}
	}
	
	function ui_validate($uri){
		$this->validate($uri);
		
		if($this->ValidResult){
			$msg1 = 'This document was successfully checked';
			$color1 = '#00CC00';
		} else {
			$msg1 = 'Errors found while checking this document';
			$color1 = '#FF3300';
		}
		$ui = '<div style="background:#FFFFFF; border:1px solid #CCCCCC; padding:2px;">
					<h1 style="color:#FFFFFF; border-bottom:1px solid #CCCCCC; margin:0; padding:5px; background:'.$color1.'; font-family:Arial, Helvetica, sans-serif; font-size:16px; font-weight:bold;">
					 '.$msg1.'
					</h1>
					<div>
						<strong>Errors:</strong><br>
						'.$this->ValidErrors.'
					</div>
				</div>';
		$this->Ui = $ui;
		if($this->SilentUi == false){
			echo $ui;
		}
		return $ui;
		
	}
	
}
function seo_w3c_validator()
{
    $validate = new W3CPageValidationApi;
    $fp = fopen("D:\log.txt","a");
    $responseTxt = $validate->validate('http://www.hashbangcode.com/blog/w3c-validation-php-class');
    if($responseTxt){
        $str .= 'Verified';
    } else {
        $str .= 'Not verified!,';
        $str .= 'Errors found: ' . $validate->ValidErrors;
    }
    $str .= "\r\n";
    fwrite($fp, $str);
    fclose($fp);
}
?>
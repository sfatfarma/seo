<?php
/**
Plugin Name: Gryphon SEO Tools
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin uses different seo techniques to boost your website in search rankings.
Author: kisded
Version: 1.0
Author URI: https://themeforest.net/user/kisded
*/
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/seo/master/info.json", __FILE__, "gryphon-seo-tools");
add_action('admin_menu', 'fwd_seo_register_my_custom_menu_page');
function fwd_seo_register_my_custom_menu_page()
{
    $seo_general_settings = get_option('seo_General_Settings', false);
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
    add_menu_page('Gryphon SEO Tools', 'Gryphon SEO Tools Settings', 'manage_options', 'fwd_seo_admin_settings', 'fwd_seo_admin_settings', plugins_url('gryphon-seo-tools/images/icon.png'));
    if ($activatedRadioValue == 'seo_YES') {
        add_submenu_page('fwd_seo_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'fwd_seo_admin_settings' );
        add_submenu_page("fwd_seo_admin_settings", "Page Title Settings", "Page Title Settings", 'manage_options', "fwd_seo_admin_title_settings", "fwd_seo_admin_title_settings");
        add_submenu_page("fwd_seo_admin_settings", "Facebook Meta Tags", "Facebook Meta Tags", 'manage_options', "fwd_seo_facebook_settings", "fwd_seo_facebook_settings");
        add_submenu_page("fwd_seo_admin_settings", "Twitter Meta Tags", "Twitter Meta Tags", 'manage_options', "fwd_seo_twitter_settings", "fwd_seo_twitter_settings");
        add_submenu_page("fwd_seo_admin_settings", "Google Meta Tags", "Google Meta Tags", 'manage_options', "fwd_seo_google_settings", "fwd_seo_google_settings");
        add_submenu_page("fwd_seo_admin_settings", "Common Meta Tags", "Common Meta Tags", 'manage_options', "fwd_seo_common_settings", "fwd_seo_common_settings");
        add_submenu_page("fwd_seo_admin_settings", "Social Links Settings", "Social Links Settings", 'manage_options', "fwd_seo_social_links_settings", "fwd_seo_social_links_settings");
        add_submenu_page("fwd_seo_admin_settings", "Web Master Validation", "Web Master Validation", 'manage_options', "fwd_seo_validation_codes_settings", "fwd_seo_validation_codes_settings");
        add_submenu_page("fwd_seo_admin_settings", "Website Crawler", "Website Crawler", 'manage_options', "seo_crawler_main", "seo_crawler_main");
        add_submenu_page("fwd_seo_admin_settings", "Sitemap Settings", "Sitemap Settings", 'manage_options', "seo_sitemap", "seo_sitemap");
        add_submenu_page("fwd_seo_admin_settings", "File Editor", "File Editor", 'manage_options', "seo_file_editor", "seo_file_editor");
        add_submenu_page("fwd_seo_admin_settings", "W3C Validator", "W3C Validator", 'manage_options', "seo_w3c_validator", "seo_w3c_validator");
    }
}
function fwd_seo_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=fwd_seo_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
$plugin = plugin_basename(__FILE__);

    
function fwd_load_admin_things() {
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action( 'admin_enqueue_scripts', 'fwd_load_admin_things' );
add_filter("plugin_action_links_$plugin", 'fwd_seo_add_settings_link');
add_action('wp_footer', 'fwd_seo_popup_footer_content');
function fwd_seo_popup_footer_content()
{
    $seo_general_settings = get_option('seo_General_Settings', false);
?><script type="text/javascript">
        var $seo_general_settings = JSON.parse('<?php
    echo json_encode($seo_general_settings);
?>');
        </script><?php
}


add_action('admin_init', 'fwd_seo_register_mysettings');
function fwd_seo_register_mysettings()
{
    register_setting('seo_option_group', 'seo_General_Settings');
    register_setting('seo_option_group2', 'seo_Title_Settings');
    register_setting('seo_option_group3', 'seo_Social_Links_Settings');
    register_setting('seo_option_group4', 'seo_Validation_Codes_Settings');
    register_setting('seo_option_group5', 'seo_Twitter_Settings');
    register_setting('seo_option_group6', 'seo_Common_Settings');
    register_setting('seo_option_group7', 'seo_Facebook_Settings');
    register_setting('seo_option_group8', 'seo_Google_Settings');
    register_setting('seo_option_group9', 'seo_Crawler_Settings');
    register_setting('seo_option_group10', 'seo_Sitemap_Settings');
}
add_action('admin_enqueue_scripts', 'fwd_seo_admin_load_files');
function fwd_seo_admin_load_files()
{
    wp_register_style('fwd-seo-popup-style', plugins_url('styles/fwd-seo.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('fwd-seo-popup-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('fwd_seo-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_seo-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_seo-settings-app', plugins_url('res/seo-angular.js', __FILE__), array(), '1.0.0', true);
}
    
require (dirname(__FILE__)."/res/seo-locale.php");
require (dirname(__FILE__)."/res/seo-logic.php");
require (dirname(__FILE__)."/res/seo-main.php");
require (dirname(__FILE__)."/res/seo-facebook.php");
require (dirname(__FILE__)."/res/seo-title.php");
require (dirname(__FILE__)."/res/seo-social-links.php");
require (dirname(__FILE__)."/res/seo-webmaster.php");
require (dirname(__FILE__)."/res/seo-twitter.php");
require (dirname(__FILE__)."/res/seo-common.php");
require (dirname(__FILE__)."/res/seo-google.php");
require (dirname(__FILE__)."/res/seo-sitemap.php");
require (dirname(__FILE__)."/res/seo-crawler.php");
require (dirname(__FILE__)."/res/seo-file-editor.php");
require (dirname(__FILE__)."/res/seo-w3c-validator.php");
?>
<?php
/**
Plugin Name: Gryphon SEO Tools
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin uses different seo techniques to boost your website in search rankings.
Author: kisded
Version: 1.0
Author URI: https://codecanyon.net/user/kisded
*/
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/seo/master/info.json", __FILE__, "gryphon-seo-tools");
add_action('admin_menu', 'fwd_seo_register_my_custom_menu_page');
function fwd_seo_register_my_custom_menu_page()
{
    $seo_general_settings = get_option('seo_General_Settings', false);
    if (isset($seo_general_settings['seo_activated_radio'])) {
        $activatedRadioValue = $seo_general_settings['seo_activated_radio'];
    } else {
        $activatedRadioValue = 'seo_NO';
    }
    add_menu_page('Gryphon SEO Tools', 'Gryphon SEO Tools Settings', 'manage_options', 'fwd_seo_admin_settings', 'fwd_seo_admin_settings', plugins_url('images/icon.png', __FILE__));
    if ($activatedRadioValue == 'seo_YES') {
        add_submenu_page('fwd_seo_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'fwd_seo_admin_settings');
        add_submenu_page("fwd_seo_admin_settings", "Page Title Settings", "Page Title Settings", 'manage_options', "fwd_seo_admin_title_settings", "fwd_seo_admin_title_settings");
        add_submenu_page("fwd_seo_admin_settings", "Facebook Meta Tags", "Facebook Meta Tags", 'manage_options', "fwd_seo_facebook_settings", "fwd_seo_facebook_settings");
        add_submenu_page("fwd_seo_admin_settings", "Twitter Meta Tags", "Twitter Meta Tags", 'manage_options', "fwd_seo_twitter_settings", "fwd_seo_twitter_settings");
        add_submenu_page("fwd_seo_admin_settings", "Google Meta Tags", "Google Meta Tags", 'manage_options', "fwd_seo_google_settings", "fwd_seo_google_settings");
        add_submenu_page("fwd_seo_admin_settings", "Common Meta Tags", "Common Meta Tags", 'manage_options', "fwd_seo_common_settings", "fwd_seo_common_settings");
        add_submenu_page("fwd_seo_admin_settings", "Social Links Settings", "Social Links Settings", 'manage_options', "fwd_seo_social_links_settings", "fwd_seo_social_links_settings");
        add_submenu_page("fwd_seo_admin_settings", "Web Master Validation", "Web Master Validation", 'manage_options', "fwd_seo_validation_codes_settings", "fwd_seo_validation_codes_settings");
        add_submenu_page("fwd_seo_admin_settings", "Sitemap Settings", "Sitemap Settings", 'manage_options', "seo_sitemap", "seo_sitemap");
        add_submenu_page("fwd_seo_admin_settings", "Miscellaneous Settings", "Miscellaneous Settings", 'manage_options', "fwd_seo_misc_settings", "fwd_seo_misc_settings");
        add_submenu_page("fwd_seo_admin_settings", "Google Analytics", "Google Analytics", 'manage_options', "seo_google_analytics", "seo_google_analytics");
        add_submenu_page("fwd_seo_admin_settings", "Breadcrumbs Settings", "Breadcrumbs Settings", 'manage_options', "seo_breadcrumbs", "seo_breadcrumbs");
        add_submenu_page("fwd_seo_admin_settings", "File Editor", "File Editor", 'manage_options', "seo_file_editor", "seo_file_editor");
        add_submenu_page("fwd_seo_admin_settings", "Website Crawler", "Website Crawler", 'manage_options', "seo_crawler_main", "seo_crawler_main");
    }
}
function fwd_seo_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=fwd_seo_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
$plugin = plugin_basename(__FILE__);


function fwd_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');       
}



add_action('admin_enqueue_scripts', 'fwd_load_admin_things');
add_filter("plugin_action_links_$plugin", 'fwd_seo_add_settings_link');
add_action('wp_footer', 'fwd_seo_popup_footer_content');
function fwd_seo_popup_footer_content()
{
    $seo_general_settings = get_option('seo_General_Settings', false);
?><script type="text/javascript">
        var $seo_general_settings = JSON.parse('<?php
    echo json_encode($seo_general_settings);
?>');
        </script><?php
}

add_action('admin_init', 'fwd_seo_register_mysettings');

function fwd_seo_register_mysettings()
{
    register_setting('seo_option_group', 'seo_General_Settings');
    register_setting('seo_option_group2', 'seo_Title_Settings');
    register_setting('seo_option_group3', 'seo_Social_Links_Settings');
    register_setting('seo_option_group4', 'seo_Validation_Codes_Settings');
    register_setting('seo_option_group5', 'seo_Twitter_Settings');
    register_setting('seo_option_group6', 'seo_Common_Settings');
    register_setting('seo_option_group7', 'seo_Facebook_Settings');
    register_setting('seo_option_group8', 'seo_Google_Settings');
    register_setting('seo_option_group10', 'seo_Sitemap_Settings');
    register_setting('seo_option_group11', 'seo_Misc_Settings');
    register_setting('seo_option_group9', 'seo_Bread_Settings');
    register_setting('seo_option_group12', 'seo_Analytics');
}

add_action('wp_ajax_my_action', 'my_action_callback');
function my_action_callback() {
     my_activation_callback();
    echo "0";
    die();
}
register_activation_hook( __FILE__, 'my_activation_callback' );
function my_activation_callback() {
    $seo_Title_Settings = array(
        'seo_post_title' => get_bloginfo('name'),
        'seo_home_desc' => get_bloginfo('description'),
        'seo_page_title' => get_bloginfo('name'),
        'seo_show_descript' => 'on',
        'seo_title_sep' => '-'
    );
    if(!get_option('seo_Title_Settings')) {
        add_option('seo_Title_Settings', $seo_Title_Settings);
    } else {
        delete_option('seo_Title_Settings');
        add_option('seo_Title_Settings', $seo_Title_Settings);
    }
    $seo_Facebook_Settings = array(
        'seo_facebook_image' => '',
        'seo_facebook_author' => '',
        'seo_facebook_publisher' => '',
        'seo_facebook' => 'on',
        'seo_facebook_locale' => 'on',
        'seo_facebook_app_id' => '',
        'seo_facebook_admin_id' => '',
        'seo_facebook_show_site_name' => 'on',
        'seo_facebook_show_title' => 'on',
        'seo_facebook_show_url' => 'on',
        'seo_facebook_show_type' => 'on',
        'seo_facebook_show_times' => 'on',
        'seo_facebook_show_image' => 'on',
        'seo_facebook_show_description' => 'on',
        'seo_facebook_show_sections' => 'on',
        'seo_facebook_type' => 'Website'
    );
    if(!get_option('seo_Facebook_Settings')) {
        add_option('seo_Facebook_Settings', $seo_Facebook_Settings);
    } else {
        delete_option('seo_Facebook_Settings');
        add_option('seo_Facebook_Settings', $seo_Facebook_Settings);
    }
    $seo_Twitter_Settings = array(
        'seo_twitter_user' => '',
        'seo_twitter_creator' => '',
        'seo_twitter_image' => '',
        'seo_twitter_image_alt' => '',
        'seo_twitter' => 'on',
        'seo_twitter_title' => 'on',
        'seo_twitter_description' => 'on',
        'seo_twitter_image_sw' => 'on',
        'seo_twitter_type' => 'summary'
    );
    if(!get_option('seo_Twitter_Settings')) {
        add_option('seo_Twitter_Settings', $seo_Twitter_Settings);
    } else {
        delete_option('seo_Twitter_Settings');
        add_option('seo_Twitter_Settings', $seo_Twitter_Settings);
    }
    $seo_Google_Settings = array(
        'seo_google_publisher' => '',
        'seo_google_en' => 'on',
        'seo_google_author' => ''
    );
    if(!get_option('seo_Google_Settings')) {
        add_option('seo_Google_Settings', $seo_Google_Settings);
    } else {
        delete_option('seo_Google_Settings');
        add_option('seo_Google_Settings', $seo_Google_Settings);
    }
    $seo_Common_Settings = array(
        'seo_common' => 'on',
        'seo_dublin' => 'on',
        'seo_canonical' => 'on',
        'seo_copyright' => '',
        'seo_language' => '',
        'seo_author' => '',
        'seo_abstract' => ''
    );
    if(!get_option('seo_Common_Settings')) {
        add_option('seo_Common_Settings', $seo_Common_Settings);
    } else {
        delete_option('seo_Common_Settings');
        add_option('seo_Common_Settings', $seo_Common_Settings);
    }
    $seo_Social_Links_Settings = array(
        'seo_facebook_profile' => '',
        'seo_social_links' => 'on',
        'seo_twitter_profile' => '',
        'seo_gplus_profile' => '',
        'seo_instagram_profile' => '',
        'seo_tumblr_profile' => '',
        'seo_pinterest_profile' => '',
        'seo_linkedin_profile' => '',
        'seo_soundcloud_profile' => '',
        'seo_youtube_profile' => ''
    );
    if(!get_option('seo_Social_Links_Settings')) {
        add_option('seo_Social_Links_Settings', $seo_Social_Links_Settings);
    } else {
        delete_option('seo_Social_Links_Settings');
        add_option('seo_Social_Links_Settings', $seo_Social_Links_Settings);
    }
    $seo_Validation_Codes_Settings = array(
        'seo_google_code' => '',
        'seo_validation_codes' => 'on',
        'seo_bing_code' => '',
        'seo_yandex_code' => '',
        'seo_pinterest_code' => ''
    );
    if(!get_option('seo_Validation_Codes_Settings')) {
        add_option('seo_Validation_Codes_Settings', $seo_Validation_Codes_Settings);
    } else {
        delete_option('seo_Validation_Codes_Settings');
        add_option('seo_Validation_Codes_Settings', $seo_Validation_Codes_Settings);
    }
    $seo_Sitemap_Settings = array(
        'seo_sitemap_enabled' => 'on',
        'seo_sitemap_post_priority' => '0.5',
        'seo_sitemap_post_update' => 'daily',
        'seo_sitemap_home_priority' => '1.0',
        'seo_sitemap_home_update' => 'weekly',
        'seo_sitemap_google' => 'on',
        'seo_sitemap_robots' => 'on',
        'seo_sitemap_robots_new' => 'on',
        'seo_sitemap_htaccess_new' => 'on',
        'seo_sitemap_add_posts' => 'seo_YES',
        'seo_sitemap_add_pages' => 'seo_YES',
        'seo_sitemap_add_att' => 'seo_YES',
        'seo_sitemap_exclude' => '',
        'seo_sitemap_number' => '1000'
    );
    if(!get_option('seo_Sitemap_Settings')) {
        add_option('seo_Sitemap_Settings', $seo_Sitemap_Settings);
    } else {
        delete_option('seo_Sitemap_Settings');
        add_option('seo_Sitemap_Settings', $seo_Sitemap_Settings);
    }
    $seo_Bread_Settings = array(
        'seo_bread_separator' => '-',
        'seo_bread_root' => 'Home',
        'seo_bread_search' => 'Search results for: ',
        'seo_bread_404' => 'Error 404',
        'seo_google_en' => 'on'
    );
    if(!get_option('seo_Bread_Settings')) {
        add_option('seo_Bread_Settings', $seo_Bread_Settings);
    } else {
        delete_option('seo_Bread_Settings');
        add_option('seo_Bread_Settings', $seo_Bread_Settings);
    }
    $seo_Analytics = array(
        'seo_google_analytics_id' => '',
        'seo_google_en' => 'on'
    );
    if(!get_option('seo_Analytics')) {
        add_option('seo_Analytics', $seo_Analytics);
    } else {
        delete_option('seo_Analytics');
        add_option('seo_Analytics', $seo_Analytics);
    }
    $seo_Misc_Settings = array(
        'seo_remove_query' => 'on',
        'seo_noindex_posts' => '',
        'seo_noindex_pages' => '',
        'seo_noindex_media' => '',
        'seo_noindex_category' => 'on',
        'seo_noindex_archive' => 'on',
        'seo_noindex_search' => '',
        'seo_noindex_tax' => '',
        'seo_noindex_nf' => '',
        'seo_noindex_home' => '',
        'seo_noindex_tag' => 'on',
        'seo_nofollow_category' => '',
        'seo_nofollow_archive' => '',
        'seo_nofollow_search' => '',
        'seo_nofollow_tax' => '',
        'seo_nofollow_nf' => '',
        'seo_nofollow_home' => '',
        'seo_nofollow_tag' => '',
        'seo_noodp_category' => '',
        'seo_noodp_archive' => '',
        'seo_noodp_search' => '',
        'seo_noodp_tax' => '',
        'seo_noodp_nf' => '',
        'seo_noodp_home' => '',
        'seo_noodp_tag' => '',
        'seo_noydir_category' => '',
        'seo_noydir_archive' => '',
        'seo_noydir_search' => '',
        'seo_noydir_tax' => '',
        'seo_noydir_nf' => '',
        'seo_noydir_home' => '',
        'seo_noydir_tag' => '',
        'seo_nofollow_posts' => '',
        'seo_nofollow_pages' => '',
        'seo_nofollow_media' => '',
        'seo_noodp_posts' => '',
        'seo_noodp_pages' => '',
        'seo_noodp_media' => '',
        'seo_noydir_posts' => '',
        'seo_noydir_pages' => '',
        'seo_noydir_media' => '',
        'seo_misc' => 'on'
    );
    if(!get_option('seo_Misc_Settings')) {
        add_option('seo_Misc_Settings', $seo_Misc_Settings);
    } else {
        delete_option('seo_Misc_Settings');
        add_option('seo_Misc_Settings', $seo_Misc_Settings);
    }
}

add_action('admin_enqueue_scripts', 'fwd_seo_admin_load_files');
function fwd_seo_admin_load_files()
{
    wp_register_style('fwd-seo-popup-style', plugins_url('styles/fwd-seo.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('fwd-seo-popup-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('fwd_seo-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_seo-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_seo-settings-app', plugins_url('res/seo-angular.js', __FILE__), array(), '1.0.0', true);
}

require(dirname(__FILE__) . "/res/seo-locale.php");
require(dirname(__FILE__) . "/res/seo-logic.php");
require(dirname(__FILE__) . "/res/seo-main.php");
require(dirname(__FILE__) . "/res/seo-facebook.php");
require(dirname(__FILE__) . "/res/seo-title.php");
require(dirname(__FILE__) . "/res/seo-social-links.php");
require(dirname(__FILE__) . "/res/seo-webmaster.php");
require(dirname(__FILE__) . "/res/seo-twitter.php");
require(dirname(__FILE__) . "/res/seo-common.php");
require(dirname(__FILE__) . "/res/seo-google.php");
require(dirname(__FILE__) . "/res/seo-sitemap.php");
require (dirname(__FILE__)."/res/seo-crawler.php");
require(dirname(__FILE__) . "/res/seo-file-editor.php");
require(dirname(__FILE__) . "/res/seo-misc.php");
require(dirname(__FILE__) . "/res/seo-breadcrumbs.php");
require(dirname(__FILE__) . "/res/seo-analytics.php");
?>